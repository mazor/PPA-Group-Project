package requirement0;

public class Contributors {

	public static void main(String[]args){
		
		System.out.println("Miriam Tamara Grodeland Aarag!");
		System.out.println("Florence Anyakwo");
		System.out.println("Sharon Mazor");
		System.out.println("Funke Sowole");

	}
	
}      