package surprise_model;

public class Player {

	private int lives;
	private Room currentRoom;
	private String name;
	
	
	public Player(Room room) {
		lives = 4;
		this.currentRoom = room;
	}


	public String getRoomUfoObservation() {
		if (!(currentRoom.isLastRoom() || currentRoom instanceof AlienRoom)) {
			return ((RegularRoom)currentRoom).getUfoObservation();
			}
		else return null; 
	}
	
	
    public int getLives() {
    	return lives;
    }
    
    
    public void setName(String name) {
    	this.name = name;
    }
    
    
    public String getName() {
    	return name;
    }
    
    
    public Room getCurrentRoom() {
    	return currentRoom;
    }
  
    
    public void moveToNextSafeRoom() {
    	if (!(currentRoom.isLastRoom())) {
    		currentRoom = ((RegularRoom)currentRoom).getNextRoom();
    	}
    }
    
    
    public void moveToAlienRoom() {
    	currentRoom = ((RegularRoom)currentRoom).getAlienRoom();
    	lives--;
    }
    
    
    public boolean isPlayerDead() {
    	return lives <= 0;
    }
}
