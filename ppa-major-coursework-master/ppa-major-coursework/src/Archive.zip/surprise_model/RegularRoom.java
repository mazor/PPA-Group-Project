package surprise_model;

public class RegularRoom extends Room {

	private Room nextRoom;
	private AlienRoom alienRoom;
	private String ufoObservation;
	private boolean isHoux;

	
	public RegularRoom(AlienRoom alienRoom, Room nextRoom) {
		super(false);
		this.alienRoom = alienRoom;
		this.nextRoom = nextRoom;
		
	}


	public void setObservation(String alienObservation, boolean isHoux) {
		this.ufoObservation = alienObservation;
		this.isHoux = isHoux;
	}


	public Room getNextRoom() {
		return nextRoom;
	}


	public AlienRoom getAlienRoom() {
		return alienRoom;
	}


	public String getUfoObservation() {
		return ufoObservation;	
    }
	
	
	public boolean isHoux() {
		return isHoux;
	}
	
}
