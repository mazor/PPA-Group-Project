package surprise_model;

public class Room {

	
	private boolean isFinalRoom;
	
	public Room(boolean isFinalRoom) {
		this.isFinalRoom = isFinalRoom;
	}
	

	public boolean isLastRoom() {
		return isFinalRoom;
	}


}