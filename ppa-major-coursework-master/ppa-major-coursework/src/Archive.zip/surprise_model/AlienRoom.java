package surprise_model;

public class AlienRoom extends Room {

	private String alien;
	private String alienWeapon;
	
	public AlienRoom(String alien, String alienWeapon) {
		super(false);
		this.alien = alien;
		this.alienWeapon = alienWeapon;	
	}
	
	public String getAlien() {
		return alien;
	}
	
	public String getAlienWeapon() {
		return alienWeapon;
	}
	
}
