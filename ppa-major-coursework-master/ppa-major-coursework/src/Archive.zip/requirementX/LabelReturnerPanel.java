package requirementX;

import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import requirementX.OrigStatistics.LeftButton;
import requirementX.OrigStatistics.RightButton;

public class LabelReturnerPanel extends JPanel{

	private JLabel jlCenter;
	private JLabel jlTitle;
	private JButton jbBack;
	private JButton jbForward1;
	
	/*public LabelReturnerPanel(requirementX.TempStatTest.LeftButton leftButton, requirementX.TempStatTest.RightButton rightButton, String title) {

			//title is created
			jlTitle=new JLabel(title, SwingConstants.CENTER);

			setLayout(new BorderLayout());
			add(jlTitle, BorderLayout.NORTH);
			jbBack =new JButton("<");
			Statistics s= new Statistics();
			jbBack.addActionListener(leftButton);
			add(jbBack, BorderLayout.WEST);
			jbForward1 =new JButton(">");
			jbForward1.addActionListener(rightButton);
			add(jbForward1, BorderLayout.EAST);

			jlCenter = new JLabel("check5", SwingConstants.CENTER);
			
			add(jlCenter, BorderLayout.CENTER);
	}*/
	public LabelReturnerPanel(String title) {

		//title is created
		jlTitle=new JLabel(title, SwingConstants.CENTER);

		setLayout(new BorderLayout());
		add(jlTitle, BorderLayout.NORTH);
		jbBack =new JButton("<");
		OrigStatistics s= new OrigStatistics();
		//jbBack.addActionListener(leftButton);
		add(jbBack, BorderLayout.WEST);
		jbForward1 =new JButton(">");
		//jbForward1.addActionListener(rightButton);
		add(jbForward1, BorderLayout.EAST);

		jlCenter = new JLabel("check5", SwingConstants.CENTER);
		
		add(jlCenter, BorderLayout.CENTER);
}


	public void setCenter(String center) {
		this.jlCenter.setText(center);
	}

	public void setActionListeners(requirementX.StatisticsPanel.LeftButton leftButton, requirementX.StatisticsPanel.RightButton rightButton){
		//to do
		jbBack.addActionListener(leftButton);
		jbForward1.addActionListener(rightButton);
		
	}

	public void setTitle(String title) {
		this.jlTitle.setText(title);
	}

	public String getTitle(){
		return jlTitle.getText();
	}

	public String getCenter(){
		return jlCenter.getText();
	}
	
	
	
	
}
