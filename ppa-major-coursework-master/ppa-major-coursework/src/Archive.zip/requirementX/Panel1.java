package requirementX;

import java.awt.GridLayout;
import javax.swing.JPanel;
import javax.swing.JTextField;
import api.ripley.Ripley;
import java.awt.Font;

public class Panel1 extends JPanel {

	private Ripley ripley;
	private static final long serialVersionUID = 1L;
	private JPanel introductionPanel;
	private JPanel explanationPanel;
	private JTextField dataSelected;
	private JTextField countdown;
	private JTextField grabbingData;


//The fields store the currently selected time period.
	private String to;
	private String from;


	
	public Panel1() { 
	setLayout(new GridLayout(5, 1)); 
	   add(introductionPanel()); 
	}

	
/**
  * This method updates the JTexFields and JPanels on Panel1.
  * This method will be called by the MainWindow when the values of the
  * JSliders change.
  */
	public void updatePanel1(String from, String to) {
	this.from = from;
	this.to = to;
	add(dataSelected());
	add(grabbingData());
	add(countdown());
	add(explanationPanel());
	}
	

	
/**
 * This method creates the introduction panel which welcomes 
 * the user to the program. 		
 * @return
 */
	private JPanel introductionPanel() {	
		introductionPanel = new JPanel(new GridLayout(4, 1));
//The first panel shows the acknowledgement string from the Ripley Library.	                
	   ripley = new Ripley("90tLI3CStdmyVD6ql2OMtA==", "lBgm4pRs8QnVqL46EnH7ew==");
	   String acknowledgmentString = ripley.getAcknowledgementString();
	   
	   JTextField textField1 = new JTextField("Welcome to Ripley v." + ripley.getVersion());
	   JTextField textField2 = new JTextField(acknowledgmentString);
	   JTextField textField3 = new JTextField("Please use the dates above to select a time period, ");
	   JTextField textField4 = new JTextField("in order to begin analysing UFO sighting data"); 
//The TextFields are set to be centred. 
	   textField1.setHorizontalAlignment(JTextField.CENTER);
	   textField2.setHorizontalAlignment(JTextField.CENTER);
	   textField3.setHorizontalAlignment(JTextField.CENTER);
	   textField4.setHorizontalAlignment(JTextField.CENTER);
//The background colour is set to be the same as the frame.    
	   textField1.setBackground(null);	   
	   textField2.setBackground(null);
	   textField3.setBackground(null);
	   textField4.setBackground(null);
//The visible borders around the textFields are removed.    
	   textField1.setBorder(null);
	   textField2.setBorder(null);
	   textField3.setBorder(null);
	   textField4.setBorder(null);
	introductionPanel.add(textField1);
	introductionPanel.add(textField2);
	introductionPanel.add(textField3);
	introductionPanel.add(textField4);
	return introductionPanel;
	}
	

/**
 * This method creates a panel which encourages the user to start utilising
 * the program.		
 * @return
 */	
	private JPanel explanationPanel() {
//The object of the Font class allows us to define our own style for the text.	
		Font font = new Font("BoldText", Font.BOLD, 12);			
		explanationPanel = new JPanel(new GridLayout(2, 1));
		JTextField textField1 = new JTextField("Please now interact with this data using the ");
		JTextField textField2 = new JTextField("buttons to the left and the right.");		    
//We set the text to be in our custom font.			
		textField1.setFont(font);
		textField2.setFont(font);
//The textfields are set to be centred.			
		textField1.setHorizontalAlignment(JTextField.CENTER);
	    textField2.setHorizontalAlignment(JTextField.CENTER);
//The background is set to be the same as the frame.
        textField1.setBackground(null);
	    textField2.setBackground(null);
//The visible borders are removed.		    
	    textField1.setBorder(null);
	    textField2.setBorder(null);	    
	    explanationPanel.add(textField1);
	    explanationPanel.add(textField2);		    
	    return explanationPanel;
	}




	/**
	 * This method creates a textField which shows the time period the user has selected. 
	 * @return
	 */
	private JTextField dataSelected() {
	dataSelected = new JTextField("Data range selected, " + from + " - " + to + ".");
	dataSelected.setHorizontalAlignment(JTextField.CENTER);
	dataSelected.setBackground(null);
	dataSelected.setBorder(null); 
	return dataSelected;
	}

	/**
	 * This method initialises the JTextField grabbingData. 
	 * @return
	 */
	private JTextField grabbingData() {
	grabbingData = new JTextField("Grabbing data...");
	grabbingData.setHorizontalAlignment(JTextField.CENTER);
	grabbingData.setBackground(null);
	grabbingData.setBorder(null);
	return grabbingData;
	}
	
	/**
	 * This method initialises the JTextField countdown. This textfield informs
	 * the user how long it will take to load the data from the database. 
	 * @return
	 */
	private JTextField countdown() {
	countdown = new JTextField("Data grabbed in ");
	countdown.setHorizontalAlignment(JTextField.CENTER);
	countdown.setBackground(null);
	countdown.setBorder(null);
	return countdown;
	}
	

}

