package requirementX;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * @authors Miriam Tamara Grodeland Aarag.
 *		Florence Anyakwo.
 *		Sharon Mazor.
 *		Funke Sowole.
 *
 */










import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import api.ripley.Incident;
import api.ripley.Ripley;
import requirementX.model.DateValidation;
import requirementX.model.StatisticValues;

public class StatisticsPanel extends JPanel{
	private ArrayList<LabelReturnerPanel> statPanels;
	private int maxI;
	private int i;
	private ArrayList<LabelReturnerPanel> mainPanels;
	private MainWindow mw;
	private Ripley ripley;
	
	private LabelReturnerPanel jpBottomRight;
	private	LabelReturnerPanel jpTopLeft;
	private	LabelReturnerPanel jpBottomLeft;
	private LabelReturnerPanel jpTopRight;
	private LabelReturnerPanel jpHoaxes;
	private ArrayList<Incident> incidentsInRange;
	private StatisticValues sv;
	
	String name ="Rememeber to edit this";
	public StatisticsPanel(MainWindow mw) {
		// TODO Auto-generated constructor stub
		i=0;
		ripley = new Ripley("90tLI3CStdmyVD6ql2OMtA==", "lBgm4pRs8QnVqL46EnH7ew==");
		sv=new StatisticValues();
		statPanels=new ArrayList<LabelReturnerPanel>();
		mainPanels=new ArrayList<LabelReturnerPanel>();
		//layout is set as a grid of 2 rows and 2 columns
		setLayout(new GridLayout(2,2));

		
		//The 4 stat boxes are intialised and added to the panel
		this.mw=mw;
		initPanels();
		add(initTopLeft());
		add(initTopRight());
		add(initBottomLeft());
		add(initBottomRight());
		maxI=statPanels.size()-1;
		
		System.out.println("a"+mw);
		System.out.println("b"+this.mw);

		
	}


	private void initPanels(){ //actually should it be another panel or since only the title and center need to change just update those whenever it reaches it?

		//however if i am doing arraylist then it'll have to be an arraylist of either jpanel or jlabels so have either jpHoaxes or jlHoaxes (for the center and do setText for title? or even do setTxt for both and have an arraylist of possible stats names and set title by that and call an appropriate method for center.
		jpHoaxes= new LabelReturnerPanel("Hoaxes");//new LeftButton(jpHoaxes), new RightButton(jpHoaxes), "Hoaxes");
		jpHoaxes.setActionListeners(new LeftButton(jpHoaxes, i), new RightButton(jpHoaxes, i));
		
		jpHoaxes.setCenter("don't forget to set this");
		jpHoaxes.setCenter(""+sv.getHoaxInfo(mw.fromDateString(), mw.toDateString()));
		statPanels.add(jpHoaxes);
	//	jpTopLeft.setName(jpHoaxes.getName());
		
		LabelReturnerPanel jpNonUS = new LabelReturnerPanel("Non US");
		jpNonUS.setActionListeners(new LeftButton(jpNonUS, i), new RightButton(jpNonUS, i));
		jpNonUS.setCenter(""+sv.getNonUSInfo(mw.fromDateString(), mw.toDateString()));
		statPanels.add(jpNonUS);
		
		LabelReturnerPanel jpLikeliestState = new LabelReturnerPanel("Likeliest State");
		jpLikeliestState.setActionListeners(new LeftButton(jpLikeliestState, i), new RightButton(jpLikeliestState, i));
		jpLikeliestState.setCenter(""+sv.getLikeliestState(mw.fromDateString(), mw.toDateString()));
		statPanels.add(jpLikeliestState);
			
		
		LabelReturnerPanel jpViaOther = new LabelReturnerPanel("Via Other Platforms");
		jpViaOther.setActionListeners(new LeftButton(jpViaOther, i), new RightButton(jpViaOther, i));
		jpViaOther.setCenter(""+sv.getViaOther(mw.fromDateString(), mw.toDateString()));
		statPanels.add(jpViaOther);
		
		LabelReturnerPanel jpExtra1 = new LabelReturnerPanel("Extra1");
		jpViaOther.setActionListeners(new LeftButton(jpExtra1, i), new RightButton(jpExtra1, i));
		statPanels.add(jpExtra1);
		
		LabelReturnerPanel jpExtra2 = new LabelReturnerPanel("Extra2");
		jpViaOther.setActionListeners(new LeftButton(jpExtra2, i), new RightButton(jpExtra2, i));
		statPanels.add(jpExtra2);
		
		LabelReturnerPanel jpExtra3 = new LabelReturnerPanel("Extra3");
		jpViaOther.setActionListeners(new LeftButton(jpExtra3, i), new RightButton(jpExtra3, i));
		statPanels.add(jpExtra3);
		
		LabelReturnerPanel jpExtra4 = new LabelReturnerPanel("Extra4");
		jpViaOther.setActionListeners(new LeftButton(jpExtra4, i), new RightButton(jpExtra4, i));
		statPanels.add(jpExtra4);
		
		
	}
	
/**
 * This returns the top left stat box
 * @return jpTopLeft: The top left stat box
 */
	private LabelReturnerPanel initTopLeft(){
		 jpTopLeft=new LabelReturnerPanel(statPanels.get(0).getTitle());
		 jpTopLeft.setCenter(statPanels.get(0).getCenter());
		 jpTopLeft.setActionListeners(new LeftButton(jpTopLeft, i), new RightButton(jpTopLeft, i));
		 mainPanels.add(jpTopLeft);
		return jpTopLeft;
		
	}


	private LabelReturnerPanel initTopRight(){
		
		jpTopRight=new LabelReturnerPanel(statPanels.get(1).getTitle());
		jpTopRight.setCenter(statPanels.get(1).getCenter());
		jpTopRight.setActionListeners(new LeftButton(jpTopRight, i), new RightButton(jpTopRight, i));
		mainPanels.add(jpTopRight);
		
		return jpTopRight;
	}
	
	private LabelReturnerPanel initBottomLeft(){
		
		jpBottomLeft=new LabelReturnerPanel(statPanels.get(2).getTitle()); 
		jpBottomLeft.setCenter(statPanels.get(2).getCenter());
		jpBottomLeft.setActionListeners(new LeftButton(jpBottomLeft, i), new RightButton(jpBottomLeft, i));
		mainPanels.add(jpBottomLeft);
		
		return jpBottomLeft;
	}

	private LabelReturnerPanel initBottomRight(){
		jpBottomRight=new LabelReturnerPanel(statPanels.get(3).getTitle()); 
		jpBottomRight.setCenter(statPanels.get(3).getCenter());
		jpBottomRight.setActionListeners(new LeftButton(jpBottomRight, i), new RightButton(jpBottomRight, i));
		mainPanels.add(jpBottomRight);
		
		return jpBottomRight;
	}
	
	public static void main (String[] args){
		
		JFrame jf = new JFrame();
		MainWindow mw=new MainWindow();

		StatisticsPanel stat = new StatisticsPanel(mw);
		
		
		jf.add(stat);
		jf.pack();
		jf.setVisible(true);
	}

	
	class LeftButton implements ActionListener{
		
		private LabelReturnerPanel panelLeft;
	//	private int i;
		
		public LeftButton(LabelReturnerPanel panelLeft, int i){
			this.panelLeft=panelLeft;
		//	this.i=i;
		}
		
		public void actionPerformed(ActionEvent e) {
			System.out.println("Error not here-left"+i);
			 if (i>0)	{
					i--;
					//panelLeft.remove(statPanels.get(i+1));
					//panelLeft.add(statPanels.get(i), BorderLayout.SOUTH);
					while ((statPanels.get(i).getTitle().equals(mainPanels.get(0).getTitle()))
							||(statPanels.get(i).getTitle().equals(mainPanels.get(1).getTitle()))
							||(statPanels.get(i).getTitle().equals(mainPanels.get(2).getTitle()))
							||(statPanels.get(i).getTitle().equals(mainPanels.get(3).getTitle()))){
						if (i==0){
							i=maxI;
						} else i--;
					}
					panelLeft.setTitle(statPanels.get(i).getTitle()); //why does this do nothing?
	
					panelLeft.setCenter(statPanels.get(i).getCenter());
	
					revalidate();
					repaint();


					}

			
		}

	}
		
	class RightButton implements ActionListener{
		
			private LabelReturnerPanel panelRight;
		//	private int i;
			
			public RightButton(LabelReturnerPanel panelRight, int i){
				this.panelRight=panelRight;
				//this.i=i;
			}
			public void actionPerformed(ActionEvent e) { 
				//this should check if there is a right panel
				//if so go to it
				//else don't
			//check validity of i 
			if (maxI!=i)	{
				i++;
				while ((statPanels.get(i).getTitle().equals(mainPanels.get(0).getTitle()))
						||(statPanels.get(i).getTitle().equals(mainPanels.get(1).getTitle()))
						||(statPanels.get(i).getTitle().equals(mainPanels.get(2).getTitle()))
						||(statPanels.get(i).getTitle().equals(mainPanels.get(3).getTitle()))){
					if (i==maxI){
						i=0;
					} else i++;
				}
				panelRight.getTitle();
				panelRight.setTitle(statPanels.get(i).getTitle()); 
				panelRight.setCenter(statPanels.get(i).getCenter());
			
			
				revalidate();
			
				
			}
			
		

	
		
			
		}
	}
	}


