package requirementX;
import java.awt.BorderLayout;
import java.awt.Graphics;

import javax.swing.JFrame;

public class Test1  extends JFrame{
	private Mapp map;
	private Model model;
	public Test1(){
		model = new Model();
		model.getStates();
		map = new Mapp(model);
		//map.setImage();
		setTitle("Panel Two Test");
		setLayout(new BorderLayout());
		add(map, BorderLayout.CENTER);
		
		
	}
	
	public static void main(String args[]){
		Test1 t = new Test1();
		t.pack();
		t.setVisible(true);
	}
}
