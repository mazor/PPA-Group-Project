package requirementX.model;

import java.util.ArrayList;
import java.util.Observable;
import java.util.TreeMap;

import javax.swing.JFrame;

import api.ripley.Incident;
import api.ripley.Ripley;
import requirementX.OrigStatistics;


public class StatisticValues extends Observable {
	
	private Ripley ripley;
	private TreeMap<String,Integer> mapstates;
	private ArrayList<Incident> incidentsInRange;

	public StatisticValues() {
	
		ripley = new Ripley("90tLI3CStdmyVD6ql2OMtA==", "lBgm4pRs8QnVqL46EnH7ew==");//(Ripley is created using private key and public key)
				
	}
	
	public String getViaOther(String startDate, String endDat){
		return "Should actually return int but this isn't complete";
	}
	public int getNonUSInfo(String startDate, String endDate){ 
		//should return number of sightings in the database where the sighting was outside the us

			incidentsInRange = ripley.getIncidentsInRange(startDate, endDate);
			int notInUS=0;

				//for each incident in the specified range do
				for (Incident incident: incidentsInRange){
					//if the state is in Canada or is 'Not Specified.' then notInUS is incremented
					if ((incident.getState().equals("ON")||incident.getState().equals("AB")||
						incident.getState().equals("BC")||incident.getState().equals("MB")
						||incident.getState().equals("NB")||incident.getState().equals("NT")
						||incident.getState().equals("NS")||incident.getState().equals("NU")
						||incident.getState().equals("PE")	||incident.getState().equals("QC")
						||incident.getState().equals("SK")||incident.getState().equals("YT")
						||incident.getState().equals("NL")
						|| (incident.getState().equals("Not specified.")))){
							notInUS++;
					} 
					

				}
					return notInUS;
		
	}
	
	public int getHoaxInfo(String startDate, String endDate){ 
		int numberOfHoaxes = 0;
		
		ArrayList<Incident> hoaxes=new ArrayList<Incident>();
		String[] parts;
		
		incidentsInRange= ripley.getIncidentsInRange(startDate,endDate);
			//System.out.println(incidentsInRange.size());
			for (Incident incident: incidentsInRange){
			
				parts= incident.getSummary().toLowerCase().split("hoax");
				if (parts.length>1){
						hoaxes.add(incident);
						numberOfHoaxes++;
					}
				}
			System.out.println(numberOfHoaxes);
			numberOfHoaxes=hoaxes.size();
			System.out.println(numberOfHoaxes);
		return numberOfHoaxes;
		
	}
	
	private void addUSStates(){
		mapstates.put("WY",0);
		mapstates.put("AK",0); 
		mapstates.put("WI",0);
		mapstates.put("WV",0);
		mapstates.put("VA",0);
		mapstates.put("VT",0);
		mapstates.put("UT",0);
		mapstates.put("TX",0);
		mapstates.put("TN",0);
		mapstates.put("SD",0);
		mapstates.put("SC",0);
		mapstates.put("RI",0);
		mapstates.put("OR",0);
		mapstates.put("OH",0);
		mapstates.put("ND",0);
		mapstates.put("NC",0);
		mapstates.put("NY",0);
		mapstates.put("NM",0);
		mapstates.put("NJ",0);
		mapstates.put("NH",0 );
		mapstates.put("NV",0);
		mapstates.put("AL",0);
		mapstates.put("AZ",0); 
		mapstates.put("AR",0); 
		mapstates.put("CA",0); 
		mapstates.put("CO",0);
		mapstates.put("CT",0); 
		mapstates.put("DE",0); 
		mapstates.put("FL",0);
		mapstates.put("GA",0);
		mapstates.put("HI",0);
		mapstates.put("ID",0);
		mapstates.put("IL",0); 
		mapstates.put("IN",0);
		mapstates.put( "IA",0);
		mapstates.put("NE",0);
		mapstates.put( "KS",0);
		mapstates.put( "KY",0); 
		mapstates.put("LA",0);
		mapstates.put("ME",0); 
		mapstates.put("MD",0);
		mapstates.put("MA",0); 
		mapstates.put("MI",0); 
		mapstates.put("MN",0); 
		mapstates.put("MS",0); 
		mapstates.put("MO",0);
		mapstates.put("MT",0);
		mapstates.put("PA",0);
		mapstates.put("WA",0);
		mapstates.put("OK", 0);

	}
	
	public String getLikeliestState(String startDate, String endDate){
		//should return the state with the most sightings
		 mapstates = new TreeMap<String,Integer >();

			incidentsInRange = ripley.getIncidentsInRange(startDate, endDate);
			addUSStates();
			String tempState;
			int tempInt=0;
			for (Incident incident: incidentsInRange){
				//System.out.println("???");
				if (!(incident.getState().equals("ON")||incident.getState().equals("AB")||
						incident.getState().equals("BC")||incident.getState().equals("MB")
						||incident.getState().equals("NB")||incident.getState().equals("NT")
						||incident.getState().equals("NS")||incident.getState().equals("NU")
						||incident.getState().equals("PE")	||incident.getState().equals("QC")
						||incident.getState().equals("SK")||incident.getState().equals("YT")
						||incident.getState().equals("NL")
						|| (incident.getState().equals("Not specified.")))){
							tempState=incident.getState();
							tempInt=0;
							if (mapstates.get(tempState)!=null){
								tempInt=mapstates.get(tempState);
							}
							mapstates.put(tempState, tempInt+1 );
				}
				
					

			} 
			String tempMostState="TX";
			int tempMostValue=mapstates.get("TX");
			String currentState="TX";
			int currentValue=mapstates.get("TX");
			for (java.util.Map.Entry<String,Integer> mapping :mapstates.entrySet()){
				currentState=mapping.getKey();
				currentValue=mapping.getValue();
				
				if (currentValue>tempMostValue){
					tempMostState=currentState;
					tempMostValue=currentValue;
				}
				
					System.out.println(mapping.getKey() +"," + mapping.getValue());
				}
			
			return("Most likely state="+tempMostState);

	}
	
public static void main (String[] args){
		
	StatisticValues sv= new StatisticValues();
		System.out.println(sv.getHoaxInfo("2016-01-01 12:12:12", "2017-03-18 12:12:12"));
		System.out.println(sv.getNonUSInfo("2015-02-28 12:12:12", "2019-03-18 12:12:12"));
	}
}
