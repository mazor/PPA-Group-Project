package requirementX.model;

import java.util.ArrayList;
import java.util.Observable;
import java.util.TreeMap;

import api.ripley.Incident;
import api.ripley.Ripley;

public class fStatistics_ extends Observable {
		
		private Ripley ripley;
		private TreeMap<String,Integer> mapstates;
		private ArrayList<Incident> incidentsInRange;

		public fStatistics_() {
		
			ripley = new Ripley("90tLI3CStdmyVD6ql2OMtA==", "lBgm4pRs8QnVqL46EnH7ew==");//(Ripley is created using private key and public key)
					
		}
		
		private int getAllIncidents(String start, String end){
				
			incidentsInRange = ripley.getIncidentsInRange(start, end);		//stores an array of incidents, from a user specified time. 
			
			for (Incident incident: incidentsInRange){
				
				if (incident.getDateAndTime().equals(null)){
					
					/*
					 * 
					 * 	1) Convert the String date into either
					 * 		-Calendar, then extract the month.
					 * 		-Or convert directly from a string, and read the index 4-6 values. 
					 * 
					 *  2) Create a case statement.
					 *     Assignment Value 1-12, to represent each month.
					 *     Inside each case statement, do a running total to find the sum of incidents.
					 *  
					 *  3) Sum the total number count per month, into 4 variables (for each season) -- this gives the TOTAL number of incidents per season.
					 *  
					 *  4) THEN - Convert the string year, to an integer. Divide the total number of incidents, by the year.
					 *  
					 *  5) THEN - Divide the year difference, by the total number of sightings.
					 *  
					 *  6) RESULT: this gives the average number of sighting per season.
					 * 
					 * 
					 * */
				}
		}
		
	
							

}
