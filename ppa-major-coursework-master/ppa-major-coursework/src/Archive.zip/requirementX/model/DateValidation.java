/**
 *  Transforms the date into Ripley Format.
 *  Checks the Ripley Earliest / Latest year
 *  Checks the date range. 
 */
package requirementX.model;

import api.ripley.Ripley;
import requirementX.MainWindow;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Observable;

import javax.swing.event.ChangeEvent;
/**
 * @authors Miriam Tamara Grodeland Aarag.
 *		Florence Anyakwo.
 *		Sharon Mazor.
 *		Funke Sowole.
 */
public class DateValidation{
	
	private MainWindow mw;
	//private Ripley theRipley;
	private SimpleDateFormat ripleyDateFormat; 
	
	private Calendar calDate;
	private String sDate;
	
	private boolean dateOrderFine; 
	private boolean dateSpanFine; 
	private static final int MAXIMUM_DATE_RANGE = 50;	//user cannot search greater than 50 years. 
	
	
	public DateValidation(MainWindow mw){
		
		this.mw = mw;
		//theRipley = new Ripley("90tLI3CStdmyVD6ql2OMtA==", "lBgm4pRs8QnVqL46EnH7ew==");
		dateSpanFine = true; 
		dateOrderFine = true;
		
	}
	public SimpleDateFormat theRipleyDateFormat(){
		
		ripleyDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");	
		return ripleyDateFormat;
	}
	//the DateSpinnerModel only accepts date. Convert to Calendar for ease of use. 
	public Calendar convertDateToCalendar(Date d){
		
		calDate = Calendar.getInstance();
		calDate.setTime(d);
		return calDate;
	}
	//convert Calendar to Ripley String 
	public String convertCalendarToRipleyString(Calendar cal){
		sDate = ripleyDateFormat.format(cal);
		return sDate;
	}
	
	//Check 1: Ensure the from date, is after the two date. 
	public boolean dateOrderFine(){
		
		//to cannot be before from.
		if (mw.getToDate().after(mw.getFromDate())){
			dateOrderFine = false;
		}
		return dateOrderFine;
				
	}
	//Check 2: Ensure the difference between from/to is less than 50.
	public boolean dateSpanFine(){
		
		//difference must be under 50 years.
		if (mw.getToDate().get(Calendar.YEAR) - (mw.getFromDate().get(Calendar.YEAR)) > MAXIMUM_DATE_RANGE){
				dateSpanFine = false;
		}
		return dateSpanFine;
		
	}
	//I created this method to set calendar values
	//The calendars 'get' method could be used to extract the data.
	//The get method could be useful for the statistics
	public void setCalendarDate(int year, int month, int date, int hourOfDay, int minute, int second){
		
		calDate.set(year,month,date,hourOfDay,minute,second);
		//use calendar's 'GET' methods, to extract data. 
	}
	public static void main(String[] args) throws ParseException{
		
		//DateValidation r = new DateValidation(new MainWindow());
		//r.convertDateToRipleyFormat("11/3/2000"); //test

	}
}
