/**
 * 
 */
package requirementX.model;


import api.ripley.Ripley;

import java.util.ArrayList;
import java.util.TreeMap;

import api.ripley.Incident;


	
/**
 * @author --
 *
 *  
	Modifier and Type

	Method and Description

	String getCity()  
	String getDateAndTime()  
	String getDuration()  
	String getIncidentID()  
	String getPosted()  
	String getShape()  
	String getState()  
	String getSummary()
	String toString()  

 *
 *
 */

public class ListOfSightings {

	
	
	ArrayList<Incident> name = new ArrayList<Incident>();
	
	incidentsInRange = ripley.getIncidentsInRange(startDate, endDate);
	
	name.getIncidentsInRange(start,end); //Provides a list of UFO sighting incidents during a given time period. 
	
	private Ripley ripley;
	private TreeMap<String,Integer> mapstates;
	private ArrayList<Incident> incidentsInRange;

	public StatisticValues() {
	
		ripley = new Ripley("90tLI3CStdmyVD6ql2OMtA==", "lBgm4pRs8QnVqL46EnH7ew==");//(Ripley is created using private key and public key)	
	}
	private int getNonUSInfo(String startDate, String endDate){ 
		//should return number of sightings in the database where the sighting was outside the us

			incidentsInRange = ripley.getIncidentsInRange(startDate, endDate);
			
			
	//For each state create an array list.
	
	
			//The key, is the STATE.
			//The map, is the array of incidents. 
	
	//MouseListener.
	
		

}
