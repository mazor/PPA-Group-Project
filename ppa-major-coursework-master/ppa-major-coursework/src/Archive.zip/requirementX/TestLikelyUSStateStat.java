package requirementX;

import java.util.ArrayList;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Pattern;

import api.ripley.Incident;
import api.ripley.Ripley;

public class TestLikelyUSStateStat {

	
	static TreeMap<String,Integer > mapstates = new TreeMap<String,Integer >();


	public static void addUSStates(){
		mapstates.put("WY",0);
		mapstates.put("AK",0); 
		mapstates.put("WI",0);
		mapstates.put("WV",0);
		mapstates.put("VA",0);
		mapstates.put("VT",0);
		mapstates.put("UT",0);
		mapstates.put("TX",0);
		mapstates.put("TN",0);
		mapstates.put("SD",0);
		mapstates.put("SC",0);
		mapstates.put("RI",0);
		mapstates.put("OR",0);
		mapstates.put("OH",0);
		mapstates.put("ND",0);
		mapstates.put("NC",0);
		mapstates.put("NY",0);
		mapstates.put("NM",0);
		mapstates.put("NJ",0);
		mapstates.put("NH",0 );
		mapstates.put("NV",0);
		mapstates.put("AL",0);
		mapstates.put("AZ",0); 
		mapstates.put("AR",0); 
		mapstates.put("CA",0); 
		mapstates.put("CO",0);
		mapstates.put("CT",0); 
		mapstates.put("DE",0); 
		mapstates.put("FL",0);
		mapstates.put("GA",0);
		mapstates.put("HI",0);
		mapstates.put("ID",0);
		mapstates.put("IL",0); 
		mapstates.put("IN",0);
		mapstates.put( "IA",0);
		mapstates.put("NE",0);
		mapstates.put( "KS",0);
		mapstates.put( "KY",0); 
		mapstates.put("LA",0);
		mapstates.put("ME",0); 
		mapstates.put("MD",0);
		mapstates.put("MA",0); 
		mapstates.put("MI",0); 
		mapstates.put("MN",0); 
		mapstates.put("MS",0); 
		mapstates.put("MO",0);
		mapstates.put("MT",0);
		mapstates.put("PA",0);
		mapstates.put("WA",0);
		mapstates.put("OK", 0);

	}
	private static ArrayList<Incident> incidentsInRange;

public static void main(String[] args) {
	int number =0;
	Ripley ripley = new Ripley("90tLI3CStdmyVD6ql2OMtA==", "lBgm4pRs8QnVqL46EnH7ew==");

	incidentsInRange = ripley.getIncidentsInRange("2016-03-01 12:12:12", "2016-03-02 12:12:12");
	addUSStates();
	String tempState;
	int tempInt=0;
	for (Incident incident: incidentsInRange){
		//System.out.println("???");
		if (!(incident.getState().equals("ON")||incident.getState().equals("AB")||
				incident.getState().equals("BC")||incident.getState().equals("MB")
				||incident.getState().equals("NB")||incident.getState().equals("NT")
				||incident.getState().equals("NS")||incident.getState().equals("NU")
				||incident.getState().equals("PE")	||incident.getState().equals("QC")
				||incident.getState().equals("SK")||incident.getState().equals("YT")
				||incident.getState().equals("NL")
				||incident.getState().equals("Not specified."))){
					tempState=incident.getState();
					tempInt=0;
					if (mapstates.get(tempState)!=null){
						tempInt=mapstates.get(tempState);
					}
					mapstates.put(tempState, tempInt+1 );
		}
		
			

	} 
	String tempMostState="TX";
	int tempMostValue=mapstates.get("TX");
	String currentState="TX";
	int currentValue=mapstates.get("TX");
	for (Map.Entry<String,Integer> mapping :mapstates.entrySet()){
		currentState=mapping.getKey();
		currentValue=mapping.getValue();
		
		if (currentValue>tempMostValue){
			tempMostState=currentState;
			tempMostValue=currentValue;
		}
		
			System.out.println(mapping.getKey() +"," + mapping.getValue());
		}
	
	System.out.println("Most likely state="+tempMostState);
	System.out.println(mapstates.size());


	}
}
