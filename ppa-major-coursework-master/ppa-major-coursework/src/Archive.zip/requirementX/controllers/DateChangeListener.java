/*
 * 
 * 
	
	ChangeListener changeListener = new ChangeListener() {
		public void stateChanged(ChangeEvent changeEvent) {
		AbstractButton abstractButton = (AbstractButton) changeEvent.getSource();
		ButtonModel buttonModel = abstractButton.getModel();
		boolean armed = buttonModel.isArmed();
		boolean pressed = buttonModel.isPressed();
		boolean selected = buttonModel.isSelected();
		System.out.println("Changed: " + armed + "/" + pressed + "/" + selected);
		}
		};
		
 * 
 * 
 * */
package requirementX.controllers;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import requirementX.MainWindow;
import requirementX.model.DateValidation;

public class DateChangeListener implements javax.swing.event.ChangeListener {

	private static final long serialVersionUID = 1L;
	private MainWindow mainWindow;
	private DateValidation dateValidation;
	private JPanel output;
	//private Calendar cal1;
	
	public DateChangeListener(MainWindow mainWindow, DateValidation dateValidation){
		
		mainWindow = new MainWindow(1);
		dateValidation = new DateValidation(mainWindow);	
		output = new JPanel();
	}
	@Override
	public void stateChanged(ChangeEvent userChangeDate) {
	
		userChangeDate.getSource();	
		
		mainWindow.getFromDate();		//the from/to dates are updated every time the user clicks the JSpinner.
		mainWindow.getToDate();
		
		
		if (dateValidation.dateSpanFine() && dateValidation.dateOrderFine()){
			
				/*
				 * 
				 *	If the date span, and date order is fine, 
				 * 	call the other panels (i.e. panel1)
				 * 
				 * 
				 * 
				 * */
				 
			
			
		}else{
			
				if (dateValidation.dateSpanFine() == false){
					
					JOptionPane.showMessageDialog(output, "Please input a date less than 50 years", "Error", JOptionPane.ERROR_MESSAGE);
				}
				if (dateValidation.dateOrderFine() == false){
					
					JOptionPane.showMessageDialog(output, "Please ensure your from date cannot exceed to", "Error", JOptionPane.ERROR_MESSAGE);
					
				}
			
		}
		
		//System.out.println("Test Output: " + userChangeDate.getSource());			
		
		//the user inputs spinner values
		//they are validated.
		//if the ranges invalid alert.
		//if it is valid, query reply API	
		//Update view, to say has data.
		//activate the map panel.
		// TODO Auto-generated method stub
		
		

	}

}
