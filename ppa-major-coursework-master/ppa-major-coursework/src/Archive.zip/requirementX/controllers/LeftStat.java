/**
 * 
 */
package requirementX.controllers;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JPanel;

/**
 * @author ukmsh
 *
 */
public class LeftStat implements ActionListener { //might be easier to do an inner class like in mainwindow

 //need to decide in Statistics whether it will have an arraylist of JPanels, JLabels or Strings. Change Object to whatever i decide later
//or even a treemap of whatever i gave above to position so that i can get position and the index can increase	to get the next object???

	/**
	 * will have to take in and assign the 4 main panels as well so that they can be compared so no two stats are the same on the screen
	 * problem is that its pass by value not reference???
	 */
	ArrayList<JPanel> stats;
	private JPanel panelLeft;
	public LeftStat(ArrayList<JPanel> stats, JPanel panelLeft) { //need to decide in stats whether it will have an arraylist of JPanels, JLabels or Strings
		// TODO Auto-generated constructor stub
		this.stats=stats;
		this.panelLeft=panelLeft;
		
		
	}

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
