package requirementX;

import java.awt.BorderLayout;
import java.awt.event.MouseListener;

import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;

import requirementX.Mapp;



public class Controllers implements MouseListener{

	public void mouseClicked(java.awt.event.MouseEvent e) {
		if(e.getSource() instanceof JLabel){
			JFrame frame1= new JFrame();
			frame1.setTitle("map");
			frame1.setSize(400,300);
			frame1.setLayout(new BorderLayout());
			JComboBox<String> combo = new JComboBox<>();
			frame1.add(combo,BorderLayout.NORTH);
			frame1.setVisible(true);
			frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame1.pack();
		}
	}
	@Override
	public void mousePressed(java.awt.event.MouseEvent e) {


	}
	@Override
	public void mouseReleased(java.awt.event.MouseEvent e) {
		// TODO Auto-generated method stub

	}
	@Override
	public void mouseEntered(java.awt.event.MouseEvent e) {
		// TODO Auto-generated method stub

	}
	@Override
	public void mouseExited(java.awt.event.MouseEvent e) {
		// TODO Auto-generated method stub

	}
	public static void main(String[] args){
		Controllers control = new Controllers();
		//control.mousePressed();
	}
}
