package requirementX;
import java.util.ArrayList;
	import java.util.regex.Pattern;

	import api.ripley.Incident;
	import api.ripley.Ripley;

public class NonUSTest {

	

		private static ArrayList<Incident> incidentsInRange;
		private static ArrayList<Incident> inUS;
		//private static ArrayList<Incident> inCanada;
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			String[] parts;
			//inCanada=new ArrayList<Incident>();
			inUS=new ArrayList<Incident>();
			int notInUS;

			Ripley test = new Ripley("90tLI3CStdmyVD6ql2OMtA==", "lBgm4pRs8QnVqL46EnH7ew==");

			incidentsInRange= test.getIncidentsInRange("2015-02-28 12:12:12", "2019-03-18 12:12:12");

			for (Incident incident: incidentsInRange){
	
				if (!(incident.getState().equals("ON")||incident.getState().equals("AB")||
						incident.getState().equals("BC")||incident.getState().equals("MB")
						||incident.getState().equals("NB")||incident.getState().equals("NT")
						||incident.getState().equals("NS")||incident.getState().equals("NU")
						||incident.getState().equals("PE")	||incident.getState().equals("QC")
						||incident.getState().equals("SK")||incident.getState().equals("YT")
						||incident.getState().equals("NL"))&& (!incident.getState().equals("Not specified."))){
					inUS.add(incident);
				} else{ System.out.println(incident.toString());}
			
				
			
			

		}
			System.out.println("Num in US="+inUS.size());
			System.out.println("Total Num="+incidentsInRange.size());
			notInUS=incidentsInRange.size()-inUS.size();
			System.out.println("Total not in US="+notInUS);
		//System.out.println(test.getAcknowledgementString());

	}

}
