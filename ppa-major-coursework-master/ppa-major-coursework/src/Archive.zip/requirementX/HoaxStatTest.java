package requirementX;

import java.util.ArrayList;
import java.util.regex.Pattern;

import api.ripley.Incident;
import api.ripley.Ripley;

public class HoaxStatTest {

	private static ArrayList<Incident> b;
	private static ArrayList<Incident> hoaxes;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] parts;
		hoaxes=new ArrayList<Incident>();
		Pattern p=Pattern.compile("((\\D)*(\\d)*)*hoax((\\D)*(\\d)*)*");
		Ripley test = new Ripley("90tLI3CStdmyVD6ql2OMtA==", "lBgm4pRs8QnVqL46EnH7ew==");
		//(Ripley is created using private key and public key)
		//System.out.println(test.getIncidentsInRange("1965-01-01 12:12:12", "1985-12-12 12:12:12"));
		b= test.getIncidentsInRange("2015-02-28 12:12:12", "2019-03-18 12:12:12");
		System.out.println(b.size());
		for (Incident i: b){
			//System.out.println("test");
			//System.out.println(i);
			//System.out.println(i.toString());
			//System.out.println(i.getSummary());
			parts= i.getSummary().toLowerCase().split("hoax");
			if (parts.length>1){
					hoaxes.add(i);
					//System.out.println(parts[0] + " AAAAA "+ parts[1]);
					System.out.println(i.getSummary());
				}
				//
			}
		System.out.print(hoaxes.size());
			
			
		
		System.out.println(test.getAcknowledgementString());

	}

}
