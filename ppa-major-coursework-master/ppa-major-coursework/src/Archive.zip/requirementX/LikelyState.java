package requirementX;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import api.ripley.Incident;
import api.ripley.Ripley;


public class LikelyState {
	 static ArrayList<Incident> shapesInRange;
	Ripley ripley = new Ripley("90tLI3CStdmyVD6ql2OMtA==", "lBgm4pRs8QnVqL46EnH7ew==");
	ArrayList<String> shapes;
	TreeMap<String,Integer> graphic= new TreeMap<String,Integer>();

	
	public void addShapes(){

		graphic.put("Flash",0);
		graphic.put("Rectangle",0);
		graphic.put("Cone",0);
		graphic.put("Egg",0);
		graphic.put("Teardrop",0);
		graphic.put("Fireball",0);
		graphic.put("Other",0);
		graphic.put("Light",0);
		graphic.put("Circle",0);
		graphic.put("Triangle",0);
		graphic.put("Fireball",0);
		graphic.put("Sphere", 0);
		graphic.put("Diamond",0);
		graphic.put("Field", 0);
		graphic.put("Disk", 0);
		graphic.put("Cigar", 0);
		graphic.put("Cylinder", 0);
		graphic.put("Oval", 0);
		graphic.put("Chevron", 0);
		graphic.put("Changing",0);
		graphic.put("Unknown",0);
		graphic.put("Formation",0);
	}

	public ArrayList<String> getShapes(){
		shapesInRange = ripley.getIncidentsInRange("2016-05-01 12:12:12", "2017-02-02 12:12:12");
		shapes = new ArrayList<String>();

		for (Incident incident: shapesInRange){
			shapes.add(incident.getShape());// why does this return true
			//shapes.size();

		}
		return shapes;
	}

	public void markShapes(){
		int j;
		int number;


		for (Map.Entry<String,Integer> mapping :graphic.entrySet()){
			number=mapping.getValue();
			
			for(j=0; j<shapes.size();j++){
				if (mapping.getKey().equals((shapes.get(j)))){

					number+=1;
					graphic.put(mapping.getKey(), number);

					//System.out.println(mapping.getKey() +"," + mapping.getValue());
				}
				
			}   
				
		}
		
			
			int maxValueInMap=(Collections.max(graphic.values()));  
	        for (Entry<String, Integer> entry : graphic.entrySet()) {  
	            if (entry.getValue()==maxValueInMap) {
	                System.out.println(entry.getKey());     
	            }
	        }

					
			
		}
		
	

	public static void main(String[] args) {
		LikelyState likely = new LikelyState();
		likely.addShapes();
		likely.getShapes();
		likely.markShapes();
		



	}
}