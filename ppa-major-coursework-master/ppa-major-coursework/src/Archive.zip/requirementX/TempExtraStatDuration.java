package requirementX;
import java.util.ArrayList;
		import java.util.regex.Pattern;

		import api.ripley.Incident;
		import api.ripley.Ripley;
		public class TempExtraStatDuration {
			private static ArrayList<Incident> incidentsInRange;
			private static ArrayList<Incident> DurationLessThanAMinute;
			private static Ripley ripley;
			
			//actually istead of most likely category- perhaps i could do an average duration?
			//convert all durations to seconds then work out the average seconds
			//if there is no duration then exclude it from average (obviously)
			
			
			public static String getAverageDuration(){
				float avrgDuration=0f;
				String[] parts;
				int totalIncidentsIncludedInStat=0;
				int totalDurationnIncludedInStat=0;

				ripley = new Ripley("90tLI3CStdmyVD6ql2OMtA==", "lBgm4pRs8QnVqL46EnH7ew==");

				incidentsInRange= ripley.getIncidentsInRange("2015-02-28 12:12:12", "2019-03-18 12:12:12");

				for (Incident incident: incidentsInRange){
		
					if (!(incident.getDuration().equals("Not specified."))){
						totalIncidentsIncludedInStat++;
						System.out.println("convert and add to total duration so far ");
					} else{ System.out.println(incident.toString());}
				
					
				
				

			}
				if (totalIncidentsIncludedInStat!=0){
					avrgDuration=totalDurationnIncludedInStat/totalIncidentsIncludedInStat;
					
				}
		
				return "The average duration for incidents in the range that included a duration is;"+avrgDuration;
			}
	
			//private static ArrayList<Incident> inCanada;
			public static void main(String[] args) {
				// TODO Auto-generated method stub
				getAverageDuration();
			}

	}



