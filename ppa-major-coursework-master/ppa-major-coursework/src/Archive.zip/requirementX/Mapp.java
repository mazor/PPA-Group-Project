/**
 * 
 */
package requirementX;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.event.MouseListener;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Map.Entry;
import java.util.TreeMap;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import requirementX.Model;



/**
 * @author florence
 *
 */
import api.ripley.Ripley;

public class Mapp extends JPanel{
	Ripley ripley1 = new Ripley("90tLI3CStdmyVD6ql2OMtA==","lBgm4pRs8QnVqL46EnH7ew==");
	JPanel image;
	private Model model;
	ImageIcon mainImage;
	private BufferedImage map;
	private BufferedImage imageGraphic;
	JLabel label1;

	

	public Mapp(Model model) {

		this.model = model;
			
		try{
			map = ImageIO.read(new File("src/map of us.png"));
		}catch (IOException e){		e.printStackTrace();
		System.out.println("no image");
		}
		try{
		imageGraphic = ImageIO.read(new File("src/ufographic.png"));
		}catch (IOException e){
			e.printStackTrace();
			System.out.println("got image");
		}
	
	}
	
		@Override
		protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.drawImage(map, 0, 0, 500, 600, null);
			g.drawImage(imageGraphic,500, 10, 35, 30, null, null);
			System.out.println("1");
		
	
			for ( Entry<String, Integer> state : model.getStates().entrySet() ) {
				g.drawImage(imageGraphic,500, 10, 35, 30, null, null);

				if (state.getKey().equals("WA") && state.getValue()<50){
					g.drawImage(imageGraphic, 40,35, 15, 25, null, null);
				}
				else if (state.getKey().equals("WA") && state.getValue()>100){
					g.drawImage(imageGraphic, 40,35, 35, 30, null, null);
				}
				if (state.getKey().equals("MT") && state.getValue()<50){
					g.drawImage(imageGraphic, 110,60, 15, 25, null, null);
				}
				else if (state.getKey().equals("MT") && state.getValue()>100){
					g.drawImage(imageGraphic, 110,60, 35, 30, null, null);
				}
				if (state.getKey().equals("ND") && state.getValue()<50){
					g.drawImage(imageGraphic, 180,80, 15, 25, null, null);
				}
				else if (state.getKey().equals("ND") && state.getValue()>100){
					g.drawImage(imageGraphic, 180,80, 35, 30, null, null);
				}
				if (state.getKey().equals("MN") && state.getValue()<50){
					g.drawImage(imageGraphic, 230,100, 15, 25, null, null);
				}
				else if (state.getKey().equals("MN") && state.getValue()>100){
					g.drawImage(imageGraphic, 230,100, 35, 30, null, null);
				}
				if (state.getKey().equals("WI") && state.getValue()<50){
					g.drawImage(imageGraphic, 270, 135, 15, 25, null, null);
				}
				else if (state.getKey().equals("WI") && state.getValue()>100){
					g.drawImage(imageGraphic, 270, 135, 35, 30, null, null);
				}
				if (state.getKey().equals("MI") && state.getValue()<50){
					g.drawImage(imageGraphic, 315, 150, 15, 25, null, null);
				}
				else if (state.getKey().equals("MI") && state.getValue()>100){
					g.drawImage(imageGraphic, 315, 150, 35, 30, null, null);
				}
				if (state.getKey().equals("NY") && state.getValue()<50){
					g.drawImage(imageGraphic, 380, 140, 15, 25, null, null);
				}
				else if (state.getKey().equals("NY") && state.getValue()>100){
					g.drawImage(imageGraphic, 380, 140, 35, 30, null, null);
				}
				if (state.getKey().equals("ME") && state.getValue()<50){
					g.drawImage(imageGraphic, 420, 55, 15, 25, null, null);
				}
				else if (state.getKey().equals("ME") && state.getValue()>100){
					g.drawImage(imageGraphic,420, 55, 35, 25, null, null);
				}
				if (state.getKey().equals("NH") && state.getValue()<50){
					g.drawImage(imageGraphic, 370, 75, 15, 25, null, null);
				}
				else if (state.getKey().equals("NH") && state.getValue()>100){
					g.drawImage(imageGraphic,370, 75, 35, 30, null, null);
				}
				if (state.getKey().equals("ID") && state.getValue()<50){
					g.drawImage(imageGraphic, 70, 140, 15, 25, null, null);
				}
				else if (state.getKey().equals("ID") && state.getValue()>100){
					g.drawImage(imageGraphic,70, 140, 35, 30, null, null);
				}
				if (state.getKey().equals("OR") && state.getValue()<50){
					g.drawImage(imageGraphic, 30, 115, 15, 25, null, null);
				}
				else if (state.getKey().equals("OR") && state.getValue()>100){
					g.drawImage(imageGraphic,30, 115, 35, 30, null, null);
				}
				if (state.getKey().equals("WY") && state.getValue()<50){
					g.drawImage(imageGraphic, 130, 150, 15, 25, null, null);
				}
				else if (state.getKey().equals("WY") && state.getValue()>100){
					g.drawImage(imageGraphic, 130, 150, 35, 30, null, null);
				}
				if (state.getKey().equals("SD") && state.getValue()<50){
					g.drawImage(imageGraphic, 190, 150, 15, 25, null, null);
				}
				else if (state.getKey().equals("SD") && state.getValue()>100){
					g.drawImage(imageGraphic,190, 150, 35, 30, null, null);
				}
				if (state.getKey().equals("NE") && state.getValue()<50){
					g.drawImage(imageGraphic, 190, 208, 15, 25, null, null);
				}
				else if (state.getKey().equals("NE") && state.getValue()>100){
					g.drawImage(imageGraphic,190, 208, 35, 30, null, null);
				}
				if (state.getKey().equals("IA") && state.getValue()<50){
					g.drawImage(imageGraphic, 245, 200, 15, 25, null, null);
				}
				else if (state.getKey().equals("IA") && state.getValue()>100){
					g.drawImage(imageGraphic,245, 200, 35, 30, null, null);
				}
				if (state.getKey().equals("IL") && state.getValue()<50){
					g.drawImage(imageGraphic, 275, 220, 15, 25, null, null);
				}
				else if (state.getKey().equals("IL") && state.getValue()>100){
					g.drawImage(imageGraphic,275, 220, 35, 30, null, null);
				}
				if (state.getKey().equals("IN") && state.getValue()<50){
					g.drawImage(imageGraphic, 295, 220, 15, 25, null, null);
				}
				else if (state.getKey().equals("IN") && state.getValue()>100){
					g.drawImage(imageGraphic,295, 220, 35, 30, null, null);
				}
				if (state.getKey().equals("OH") && state.getValue()<50){
					g.drawImage(imageGraphic, 325, 220, 15, 25, null, null);
				}
				else if (state.getKey().equals("OH") && state.getValue()>100){
					g.drawImage(imageGraphic,325, 220, 35, 30, null, null);
				}
				if (state.getKey().equals("PA") && state.getValue()<50){
					g.drawImage(imageGraphic, 375, 190, 15, 25, null, null);
				}
				else if (state.getKey().equals("PA") && state.getValue()>100){
					g.drawImage(imageGraphic,375, 190, 35, 30, null, null);
				}
				if (state.getKey().equals("CA") && state.getValue()<50){
					g.drawImage(imageGraphic, 20, 250, 15, 25, null, null);
				}
				else if (state.getKey().equals("CA") && state.getValue()>100){
					g.drawImage(imageGraphic,20, 250, 35, 30, null, null);
				}
				if (state.getKey().equals("NV") && state.getValue()<50){
					g.drawImage(imageGraphic, 54, 225, 15, 25, null, null);
				}
				else if (state.getKey().equals("NV") && state.getValue()>100){
					g.drawImage(imageGraphic,54, 225, 35, 30, null, null);
				}
				if (state.getKey().equals("UT") && state.getValue()<50){
					g.drawImage(imageGraphic, 94, 225, 35, 40, null, null);
				}
				else if (state.getKey().equals("UT") && state.getValue()>100){
					g.drawImage(imageGraphic,94, 225, 35, 30, null, null);
				}
				if (state.getKey().equals("CO") && state.getValue()<50){
					g.drawImage(imageGraphic, 140, 245, 15, 25, null, null);
				}
				else if (state.getKey().equals("CO") && state.getValue()>100){
					g.drawImage(imageGraphic,140, 245, 35, 30, null, null);
				}
				if (state.getKey().equals("KS") && state.getValue()<50){
					g.drawImage(imageGraphic, 200, 270, 15, 25, null, null);
				}
				else if (state.getKey().equals("KS") && state.getValue()>100){
					g.drawImage(imageGraphic,200, 270, 35, 30, null, null);
				}
				if (state.getKey().equals("MO") && state.getValue()<50){
					g.drawImage(imageGraphic,  250, 270, 15, 25, null, null);
				}
				else if (state.getKey().equals("MO") && state.getValue()>100){
					g.drawImage(imageGraphic, 250, 270, 35, 30, null, null);
				}
				if (state.getKey().equals("KY") && state.getValue()<50){
					g.drawImage(imageGraphic, 320, 285, 25, 40, null, null);
				}
				else if (state.getKey().equals("KY") && state.getValue()>100){
					g.drawImage(imageGraphic,320, 285, 35, 30, null, null);
				}
				if (state.getKey().equals("WV") && state.getValue()<50){
					g.drawImage(imageGraphic, 351, 245, 15, 25, null, null);
				}
				else if (state.getKey().equals("WV") && state.getValue()>100){
					g.drawImage(imageGraphic,351, 245, 35, 30, null, null);
				}
				if (state.getKey().equals("VA") && state.getValue()<50){
					g.drawImage(imageGraphic,  370, 265, 15, 25, null, null);
				}
				else if (state.getKey().equals("VA") && state.getValue()>100){
					g.drawImage(imageGraphic, 370, 265, 35, 30, null, null);
				}
				if (state.getKey().equals("NC") && state.getValue()<50){
					g.drawImage(imageGraphic, 360, 305, 15, 25, null, null);
				}
				else if (state.getKey().equals("NC") && state.getValue()>100){
					g.drawImage(imageGraphic,360, 305, 35, 30, null, null);
				}
				if (state.getKey().equals("TN") && state.getValue()<50){
					g.drawImage(imageGraphic, 300, 320, 15, 25, null, null);
				}
				else if (state.getKey().equals("TN") && state.getValue()>100){
					g.drawImage(imageGraphic,300, 320, 35, 30, null, null);
				}
				if (state.getKey().equals("AR") && state.getValue()<50){
					g.drawImage(imageGraphic, 255, 350, 15, 25, null, null);
				}
				else if (state.getKey().equals("AR") && state.getValue()>100){
					g.drawImage(imageGraphic,255, 350, 35, 25, null, null);
				}
				if (state.getKey().equals("OK") && state.getValue()<50){
					g.drawImage(imageGraphic, 215, 348, 15, 25, null, null);
				}
				else if (state.getKey().equals("OK") && state.getValue()>100){
					g.drawImage(imageGraphic,215, 348, 35, 30, null, null);
				}
				if (state.getKey().equals("TX") && state.getValue()<50){
					g.drawImage(imageGraphic, 195, 425, 15, 25, null, null);
				}
				else if (state.getKey().equals("TX") && state.getValue()>100){
					g.drawImage(imageGraphic,195, 425, 35, 30, null, null);
				}
				if (state.getKey().equals("NM") && state.getValue()<50){
					g.drawImage(imageGraphic, 135, 360, 15, 25, null, null);
				}
				else if (state.getKey().equals("NM") && state.getValue()>100){
					g.drawImage(imageGraphic,135, 360, 35, 30, null, null);
				}
				if (state.getKey().equals("AZ") && state.getValue()<50){
					g.drawImage(imageGraphic, 80, 345, 15, 25, null, null);
				}
				else if (state.getKey().equals("AZ") && state.getValue()>100){
					g.drawImage(imageGraphic,80, 345, 35, 30, null, null);
				}
				if (state.getKey().equals("CA") && state.getValue()<50){
					g.drawImage(imageGraphic, 20, 255, 15, 25, null, null);
				}
				else if (state.getKey().equals("CA") && state.getValue()>100){
					g.drawImage(imageGraphic,20, 255, 35, 30, null, null);
				}
				if (state.getKey().equals("AK") && state.getValue()<50){
					g.drawImage(imageGraphic, 40, 470, 15, 25, null, null);
				}
				else if (state.getKey().equals("AK") && state.getValue()>100){
					g.drawImage(imageGraphic,40, 470, 35, 30, null, null);
				}
				if (state.getKey().equals("FL") && state.getValue()<50){
					g.drawImage(imageGraphic, 340, 465, 15, 25, null, null);
				}
				else if (state.getKey().equals("FL") && state.getValue()>100){
					g.drawImage(imageGraphic,340, 465, 35, 30, null, null);
				}
				if (state.getKey().equals("GA") && state.getValue()<50){
					g.drawImage(imageGraphic, 340, 395, 15, 25, null, null);
				}
				else if (state.getKey().equals("GA") && state.getValue()>100){
					g.drawImage(imageGraphic,340, 395, 35, 30, null, null);
				}
				if (state.getKey().equals("AL") && state.getValue()<50){
					g.drawImage(imageGraphic, 310, 395, 15, 30, null, null);
				}
				else if (state.getKey().equals("AL") && state.getValue()>100){
					g.drawImage(imageGraphic,310, 395, 35, 30, null, null);
				}
				if (state.getKey().equals("MS") && state.getValue()<50){
					g.drawImage(imageGraphic, 280, 395, 15, 25, null, null);
				}
				else if (state.getKey().equals("MS") && state.getValue()>100){
					g.drawImage(imageGraphic,280, 395, 35, 25, null, null);
				}
				if (state.getKey().equals("LA") && state.getValue()<50){
					g.drawImage(imageGraphic, 260, 435, 15, 25, null, null);
				}
				else if (state.getKey().equals("LA") && state.getValue()>100){
					g.drawImage(imageGraphic,260, 435, 35, 30, null, null);
				}
				if (state.getKey().equals("SC") && state.getValue()<50){
					g.drawImage(imageGraphic, 360, 355, 15, 25, null, null);
				}
				else if (state.getKey().equals("SC") && state.getValue()>100){
					g.drawImage(imageGraphic, 360, 355, 35, 30, null, null);
				}
				if (state.getKey().equals("HI") && state.getValue()<50){
					g.drawImage(imageGraphic, 130, 525, 15, 25, null, null);
				}
				else if (state.getKey().equals("HI") && state.getValue()>100){
					g.drawImage(imageGraphic,130, 525, 35, 30, null, null);
				}

	
		
			}
		
		}
		}
