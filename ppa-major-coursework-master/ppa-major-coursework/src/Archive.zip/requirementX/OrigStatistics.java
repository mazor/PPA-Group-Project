/**
 * 
 */
package requirementX;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;
import java.util.TreeMap;

/**
 * @authors Miriam Tamara Grodeland Aarag.
 *		Florence Anyakwo.
 *		Sharon Mazor.
 *		Funke Sowole.
 *
 */


import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import api.ripley.Incident;
import api.ripley.Ripley;



//ideas for class:
/*
 * 1. maybe instead of having 4 separate methods for intialising JPanels, have 1 that takes a JPanel in and returns the updated version?
 * 2. figure out how to access the JLabels - maybe through creating fields?
 * 3. action listeners for buttons need to be created -controllers? could be accessible from mainwindow too possibly
 * 4. MVC needs to be held so talk to group about that
 * 5. where are the stats coming from?
 * 6. talk to group about which stat we should do?
 * 7. arraylist for panels (one for hoaxes, one for outside us etc.)
 * 8. topleft will be equal to the other panell after checking other 3 first
 * 9. maybe an arraylist of JLabels instead or create a new class that extends JPanel and returns jlabels
 * 10. how to get titles/label info?
 * 
 * Changes made to panel1 by me:
 * 1. changed spelling of explanation
 * 2. added a question on selectedData: this is never initialised or set as anything so it will always be null?????
 * 
 * Problems with mainwindow:
 * 1. where do the buttons need to go? west and east or south (in which case why do i need west/east?)
 * 2. JSpinners or comboboxes in north?
 * 3. north has to be centered or aligned right?
 * 
 * 
 * https://developers.google.com/youtube/v3/code_samples/java       ?????????
 * https://developers.google.com/api-client-library/java/apis/
 * https://developers.google.com/eclipse/docs/getting_started?pageId=107515657821281628167
 */

public class OrigStatistics extends JPanel implements Observer {
	
	private ArrayList<JPanel> statPanels;
	private int i;
	private ArrayList<JPanel> mainPanels;
	private TreeMap<String,Integer> mapstates;
	private ArrayList<Incident> incidentsInRange;

	//should these even be fields if i have an array that holds them?
	private JPanel jpBottomRight;
	private JPanel jpTopLeft;
	private JPanel jpBottomLeft;
	private JPanel jpTopRight;
	private Ripley ripley;
	/**
	 * The constructor initialises the panel
	 */
	public OrigStatistics(){
		i=0;
		ripley = new Ripley("90tLI3CStdmyVD6ql2OMtA==", "lBgm4pRs8QnVqL46EnH7ew==");//(Ripley is created using private key and public key)
		statPanels=new ArrayList<JPanel>();
		mainPanels=new ArrayList<JPanel>();
		//layout is set as a grid of 2 rows and 2 columns
		setLayout(new GridLayout(2,2));

		
		//The 4 stat boxes are intialised and added to the panel
		add(initTopLeft());
		add(initTopRight());
		add(initBottomLeft());
		add(initBottomRight());
		//add(jpHoaxes); added just to check. should NOT have 5 boxes
		initPanels();
		mainPanels.add(new JPanel());
		mainPanels.add(new JPanel());
		mainPanels.add(new JPanel());
		mainPanels.add(new JPanel());
		
	}
	private int getHoaxInfo(String startDate, String endDate){ //how will this be worked out?, regEx? split?
		//description component annotation contains whether it is a hoax or not
		//stat should count the number of hoaxes in a selected date range
		int numberOfHoaxes = 0;
		
		
		ArrayList<Incident> hoaxes=new ArrayList<Incident>();
		String[] parts;
		
		incidentsInRange= ripley.getIncidentsInRange(startDate,endDate);
			//System.out.println(incidentsInRange.size());
			for (Incident incident: incidentsInRange){
			
				parts= incident.getSummary().toLowerCase().split("hoax");
				if (parts.length>1){
						hoaxes.add(incident);
						//System.out.println(parts[0] + " AAAAA "+ parts[1]);
					//	System.out.println(incident.getSummary());
					}
					//
				}
			numberOfHoaxes=hoaxes.size();

		return numberOfHoaxes;
		
	}
	
	private int getNonUSInfo(String startDate, String endDate){ //how will this be worked out?
		//should return number of sightings in the database where the sighting was outside the us

		incidentsInRange = ripley.getIncidentsInRange(startDate, endDate);
			int notInUS=0;

				//for each incident in the specified range do
				for (Incident incident: incidentsInRange){
					//if the state is in Canada or is 'Not Specified.' then notInUS is incremented
					if ((incident.getState().equals("ON")||incident.getState().equals("AB")||
						incident.getState().equals("BC")||incident.getState().equals("MB")
						||incident.getState().equals("NB")||incident.getState().equals("NT")
						||incident.getState().equals("NS")||incident.getState().equals("NU")
						||incident.getState().equals("PE")	||incident.getState().equals("QC")
						||incident.getState().equals("SK")||incident.getState().equals("YT")
						||incident.getState().equals("NL")
						|| (incident.getState().equals("Not specified.")))){
							notInUS++;
					} 
					

				}
					return notInUS;
		
	}
	private void addUSStates(){
		mapstates.put("WY",0);
		mapstates.put("AK",0); 
		mapstates.put("WI",0);
		mapstates.put("WV",0);
		mapstates.put("VA",0);
		mapstates.put("VT",0);
		mapstates.put("UT",0);
		mapstates.put("TX",0);
		mapstates.put("TN",0);
		mapstates.put("SD",0);
		mapstates.put("SC",0);
		mapstates.put("RI",0);
		mapstates.put("OR",0);
		mapstates.put("OH",0);
		mapstates.put("ND",0);
		mapstates.put("NC",0);
		mapstates.put("NY",0);
		mapstates.put("NM",0);
		mapstates.put("NJ",0);
		mapstates.put("NH",0 );
		mapstates.put("NV",0);
		mapstates.put("AL",0);
		mapstates.put("AZ",0); 
		mapstates.put("AR",0); 
		mapstates.put("CA",0); 
		mapstates.put("CO",0);
		mapstates.put("CT",0); 
		mapstates.put("DE",0); 
		mapstates.put("FL",0);
		mapstates.put("GA",0);
		mapstates.put("HI",0);
		mapstates.put("ID",0);
		mapstates.put("IL",0); 
		mapstates.put("IN",0);
		mapstates.put( "IA",0);
		mapstates.put("NE",0);
		mapstates.put( "KS",0);
		mapstates.put( "KY",0); 
		mapstates.put("LA",0);
		mapstates.put("ME",0); 
		mapstates.put("MD",0);
		mapstates.put("MA",0); 
		mapstates.put("MI",0); 
		mapstates.put("MN",0); 
		mapstates.put("MS",0); 
		mapstates.put("MO",0);
		mapstates.put("MT",0);
		mapstates.put("PA",0);
		mapstates.put("WA",0);
		mapstates.put("OK", 0);

	}
	
	private String getLikeliestState(String startDate, String endDate){
		//should return the state with the most sightings
		 mapstates = new TreeMap<String,Integer >();

			incidentsInRange = ripley.getIncidentsInRange(startDate, endDate);
			addUSStates();
			String tempState;
			int tempInt=0;
			for (Incident incident: incidentsInRange){
				//System.out.println("???");
				if (!(incident.getState().equals("ON")||incident.getState().equals("AB")||
						incident.getState().equals("BC")||incident.getState().equals("MB")
						||incident.getState().equals("NB")||incident.getState().equals("NT")
						||incident.getState().equals("NS")||incident.getState().equals("NU")
						||incident.getState().equals("PE")	||incident.getState().equals("QC")
						||incident.getState().equals("SK")||incident.getState().equals("YT")
						||incident.getState().equals("NL")
						|| (incident.getState().equals("Not specified.")))){
							tempState=incident.getState();
							tempInt=0;
							if (mapstates.get(tempState)!=null){
								tempInt=mapstates.get(tempState);
							}
							mapstates.put(tempState, tempInt+1 );
				}
				
					

			} 
			String tempMostState="TX";
			int tempMostValue=mapstates.get("TX");
			String currentState="TX";
			int currentValue=mapstates.get("TX");
			for (java.util.Map.Entry<String,Integer> mapping :mapstates.entrySet()){
				currentState=mapping.getKey();
				currentValue=mapping.getValue();
				
				if (currentValue>tempMostValue){
					tempMostState=currentState;
					tempMostValue=currentValue;
				}
				
					System.out.println(mapping.getKey() +"," + mapping.getValue());
				}
			
			return("Most likely state="+tempMostState);

	}
	
	private int getSightingsFromOtherPlatforms(String startDate, String endDate){ //how will this be worked out?
	//use google api to search youtube for ufo sightings
		return 0;
	}
	private void initPanels(){ //actually should it be another panel or since only the title and center need to change just update those whenever it reaches it?
		//however if i am doing arraylist then it'll have to be an arraylist of either jpanel or jlabels so have either jpHoaxes or jlHoaxes (for the center and do setText for title? or even do setTxt for both and have an arraylist of possible stats names and set title by that and call an appropriate method for center.
		JPanel jpHoaxes = new JPanel();
		//title is created
		JLabel jlTitleTL=new JLabel("Hoaxes", SwingConstants.CENTER);
		jpHoaxes.setLayout(new BorderLayout());
		jpHoaxes.add(jlTitleTL, BorderLayout.NORTH);
		JButton jbBack =new JButton("<");
		jpHoaxes.add(jbBack, BorderLayout.WEST);
		JButton jbForward =new JButton(">");
		jpHoaxes.add(jbForward, BorderLayout.EAST);
		JLabel jlCenter = new JLabel("", SwingConstants.CENTER);
		jpHoaxes.add(jlCenter, BorderLayout.CENTER);	
		statPanels.add(jpHoaxes);
		jpTopLeft.setName(jpHoaxes.getName());
		
		JPanel jpNonUS = new JPanel();
		//title is created
		JLabel jlTitleTR=new JLabel("Non-US Sightings", SwingConstants.CENTER);
		jpNonUS.setLayout(new BorderLayout());
		jpNonUS.add(jlTitleTR, BorderLayout.NORTH);
		JButton jbBack1 =new JButton("<");
		jpHoaxes.add(jbBack1, BorderLayout.WEST);
		JButton jbForward1 =new JButton(">");
		jpHoaxes.add(jbForward1, BorderLayout.EAST);
		JLabel jlCenter1 = new JLabel("", SwingConstants.CENTER);
		jpHoaxes.add(jlCenter1, BorderLayout.CENTER);	
		statPanels.add(jpNonUS);
		
		JPanel jpLikeliestState = new JPanel();
		//title is created
		JLabel jlTitleBL=new JLabel("Likeliest State", SwingConstants.CENTER);
		jpLikeliestState.setLayout(new BorderLayout());
		jpLikeliestState.add(jlTitleBL, BorderLayout.NORTH);
		JButton jbBack2 =new JButton("<");
		jpLikeliestState.add(jbBack2, BorderLayout.WEST);
		JButton jbForward2 =new JButton(">");
		jpLikeliestState.add(jbForward2, BorderLayout.EAST);
		JLabel jlCenter2 = new JLabel("", SwingConstants.CENTER);
		jpLikeliestState.add(jlCenter2, BorderLayout.CENTER);	
		statPanels.add(jpLikeliestState);
		
		
		
		JPanel jpViaOther = new JPanel();
		//title is created
		JLabel jlTitleBR=new JLabel("Sightings via other platforms", SwingConstants.CENTER);
		jpViaOther.setLayout(new BorderLayout());
		jpViaOther.add(jlTitleBR, BorderLayout.NORTH);
		JButton jbBack3 =new JButton("<");
		jpViaOther.add(jbBack3, BorderLayout.WEST);
		JButton jbForward3 =new JButton(">");
		jpViaOther.add(jbForward3, BorderLayout.EAST);
		JLabel jlCenter3 = new JLabel("", SwingConstants.CENTER);
		jpViaOther.add(jlCenter3, BorderLayout.CENTER);	
		statPanels.add(jpViaOther);
		
		
	}
	
/**
 * This returns the top left stat box
 * @return jpTopLeft: The top left stat box
 */
	private JPanel initTopLeft(){
		
		 jpTopLeft=new JPanel();
		//title is created
		JLabel jlTitleTL=new JLabel("remember to change this to actual title1", SwingConstants.CENTER);

		jpTopLeft.setLayout(new BorderLayout());
		jpTopLeft.add(jlTitleTL, BorderLayout.NORTH);
		JButton jbBack1 =new JButton("<");
		LeftButton lb = new LeftButton(jpTopLeft);
		jbBack1.addActionListener(lb);
		jpTopLeft.add(jbBack1, BorderLayout.WEST);
		JButton jbForward1 =new JButton(">");
		RightButton rb = new RightButton(jpTopLeft);
		jbForward1.addActionListener(rb);
		jpTopLeft.add(jbForward1, BorderLayout.EAST);

		JLabel jlCenter1 = new JLabel("check1", SwingConstants.CENTER);
		
		jpTopLeft.add(jlCenter1, BorderLayout.CENTER);
		//panels.add(jpTopLeft);-GOOD EXAMPLE AS OF WHAT NOT TO DO. YOU CAN'T ADD A PANEL TO ITSELF WHICH IS WHAT THE ACTIONLISTENER WOULD TRY TO DO
		return jpTopLeft;
		
	}


	private JPanel initTopRight(){
		
		jpTopRight=new JPanel(); //new panel created to represent the top right stat box
		
		JLabel jlTitleTR=new JLabel("remember to change this to actual title2", SwingConstants.CENTER); //represents the stat title, centralised text
		
		jpTopRight.setLayout(new BorderLayout());
		jpTopRight.add(jlTitleTR, BorderLayout.NORTH);
		
		JButton jbBack2 =new JButton("<");
		jpTopRight.add(jbBack2, BorderLayout.WEST);
		
		JButton jbForward2 =new JButton(">");
		jpTopRight.add(jbForward2, BorderLayout.EAST);
		
	
		JLabel jlCenter2 = new JLabel("check2", SwingConstants.CENTER);
	
		jpTopRight.add(jlCenter2, BorderLayout.CENTER);
		
		return jpTopRight;
	}
	
	private JPanel initBottomLeft(){
		
		jpBottomLeft=new JPanel();
		
		JLabel jlTitleBL=new JLabel("remember to change this to actual title3", SwingConstants.CENTER);
		jpBottomLeft.setLayout(new BorderLayout());
		jpBottomLeft.add(jlTitleBL, BorderLayout.NORTH);
		
		JButton jbBack3 =new JButton("<");
		jpBottomLeft.add(jbBack3, BorderLayout.WEST);
		
		JButton jbForward3 =new JButton(">");
		
		jpBottomLeft.add(jbForward3, BorderLayout.EAST);
	
		JLabel jlCenter3 = new JLabel("check3", SwingConstants.CENTER);

		jpBottomLeft.add(jlCenter3, BorderLayout.CENTER);
	
		
		return jpBottomLeft;
	}

	private JPanel initBottomRight(){
		
		jpBottomRight=new JPanel();
		
		JLabel jlTitleBR=new JLabel("remember to change this to actual title4", SwingConstants.CENTER);
		
		jpBottomRight.setLayout(new BorderLayout());
		jpBottomRight.add(jlTitleBR, BorderLayout.NORTH);
		
		JButton jbBack4 =new JButton("<");
		jpBottomRight.add(jbBack4, BorderLayout.WEST);
		
		JButton jbForward4 =new JButton(">");
	
		jpBottomRight.add(jbForward4, BorderLayout.EAST);
		
		JLabel jlCenter4 = new JLabel("check4", SwingConstants.CENTER);
		
		jpBottomRight.add(jlCenter4, BorderLayout.CENTER);
	
		return jpBottomRight;
	}
	

	
	/**
	 * THE ACTIONLISTENERS WORK *BUT* THEY ADD THE PANEL TO THE SOUTH ATM. EITHER MAKE IT SO THAT THE JLABELS CHANGE OR FIGURE SOMETHING ELSE OUT
	 * @author ukmsh
	 *
	 */
	
	class LeftButton implements ActionListener{
		
		private JPanel panelLeft;
		
		public LeftButton(JPanel panelLeft){
			this.panelLeft=panelLeft;
		}
		
		public void actionPerformed(ActionEvent e) {
			 if (i>0)	{
					i--;
					panelLeft.remove(statPanels.get(i+1));
					panelLeft.add(statPanels.get(i), BorderLayout.SOUTH);
					System.out.println("Error check-left");
					revalidate();
					
				}
			 System.out.println("Error check-left");

			
		}
	}
		
	class RightButton implements ActionListener{
		
			private JPanel panelRight;
			
			public RightButton(JPanel panelRight){
				this.panelRight=panelRight;
			}
			public void actionPerformed(ActionEvent e) { 
				//this should check if there is a right panel
				//if so go to it
				//else don't
			//check validity of i 
			if (statPanels.size()!=(i+1))	{
				i++;
				panelRight.remove(statPanels.get(i-1));
				panelRight.add(statPanels.get(i), BorderLayout.CENTER);
				//jpCenter=panels.get(i);
				System.out.println("Error check-right");
				
			}
			
		

	
		
			
		}
	}	public static void main (String[] args){
		
		JFrame jf = new JFrame();
		OrigStatistics stat = new OrigStatistics();
		jf.add(stat);
		jf.pack();
		jf.setVisible(true);
		System.out.println(stat.getHoaxInfo("2016-01-01 12:12:12", "2017-03-18 12:12:12"));
		System.out.println(stat.getNonUSInfo("2015-02-28 12:12:12", "2019-03-18 12:12:12"));
	}
	@Override
	public void update(Observable arg0, Object arg1) {
		// TODO Auto-generated method stub
		//get title from each panel on screen and decide which method to call using case switch statement
		//update center label accordingly
	}
}

