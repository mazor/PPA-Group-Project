package requirementX;

import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseListener;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Map.Entry;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import api.ripley.Ripley;
import requirementX.Mapp.Listener;

import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class View {

public class Mapp extends JPanel{
	Ripley ripley1 = new Ripley("90tLI3CStdmyVD6ql2OMtA==","lBgm4pRs8QnVqL46EnH7ew==");
	JPanel image;
	JLabel map;
	private Model model;
	ImageIcon mainImage;

	public Mapp(Model model) {

		this.model = model;
		
		//Mapp.add(panel);
		}
//	public void initMap(){
//		getContentPane().setLayout(new BorderLayout());
//		myPanel panel = new myPanel(); 
//		getContentPane().setSize(1000,550);
//		getContentPane().add(panel,BorderLayout.CENTER);
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		setResizable(true);
//		pack();
//
//	}
	
	
		@Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			BufferedImage scaledImage;
			BufferedImage image2;
			try {
				scaledImage = ImageIO.read(new File("src/map of us.png"));
				ImageIcon icon = new ImageIcon(scaledImage);
				JLabel label = new JLabel();
				label.setIcon(icon);
				label.addMouseListener(new Listener());

				g.drawImage(scaledImage, 0, 0, 500, 600, null);
				// Loop through states + number of incidents
				for ( Entry<String, Integer> state : model.getStates().entrySet() ) {
					 image2 = ImageIO.read(new File("src/ufographic.png"));
					g.drawImage(image2,500, 10, 35, 30, null, null);

					if (state.getKey().equals("WA") && state.getValue()<50){
						g.drawImage(image2, 40,35, 15, 25, null, null);
					}
					else if (state.getKey().equals("WA") && state.getValue()>100){
						g.drawImage(image2, 40,35, 35, 30, null, null);
					}
					if (state.getKey().equals("MT") && state.getValue()<50){
						g.drawImage(image2, 110,60, 15, 25, null, null);
					}
					else if (state.getKey().equals("MT") && state.getValue()>100){
						g.drawImage(image2, 110,60, 35, 30, null, null);
					}
					if (state.getKey().equals("ND") && state.getValue()<50){
						g.drawImage(image2, 180,80, 15, 25, null, null);
					}
					else if (state.getKey().equals("ND") && state.getValue()>100){
						g.drawImage(image2, 180,80, 35, 30, null, null);
					}
					if (state.getKey().equals("MN") && state.getValue()<50){
						g.drawImage(image2, 230,100, 15, 25, null, null);
					}
					else if (state.getKey().equals("MN") && state.getValue()>100){
						g.drawImage(image2, 230,100, 35, 30, null, null);
					}
					if (state.getKey().equals("WI") && state.getValue()<50){
						g.drawImage(image2, 270, 135, 15, 25, null, null);
					}
					else if (state.getKey().equals("WI") && state.getValue()>100){
						g.drawImage(image2, 270, 135, 35, 30, null, null);
					}
					if (state.getKey().equals("MI") && state.getValue()<50){
						g.drawImage(image2, 315, 150, 15, 25, null, null);
					}
					else if (state.getKey().equals("MI") && state.getValue()>100){
						g.drawImage(image2, 315, 150, 35, 30, null, null);
					}
					if (state.getKey().equals("NY") && state.getValue()<50){
						g.drawImage(image2, 380, 140, 15, 25, null, null);
					}
					else if (state.getKey().equals("NY") && state.getValue()>100){
						g.drawImage(image2, 380, 140, 35, 30, null, null);
					}
					if (state.getKey().equals("ME") && state.getValue()<50){
						g.drawImage(image2, 420, 55, 15, 25, null, null);
					}
					else if (state.getKey().equals("ME") && state.getValue()>100){
						g.drawImage(image2,420, 55, 35, 25, null, null);
					}
					if (state.getKey().equals("NH") && state.getValue()<50){
						g.drawImage(image2, 370, 75, 15, 25, null, null);
					}
					else if (state.getKey().equals("NH") && state.getValue()>100){
						g.drawImage(image2,370, 75, 35, 30, null, null);
					}
					if (state.getKey().equals("ID") && state.getValue()<50){
						g.drawImage(image2, 70, 140, 15, 25, null, null);
					}
					else if (state.getKey().equals("ID") && state.getValue()>100){
						g.drawImage(image2,70, 140, 35, 30, null, null);
					}
					if (state.getKey().equals("OR") && state.getValue()<50){
						g.drawImage(image2, 30, 115, 15, 25, null, null);
					}
					else if (state.getKey().equals("OR") && state.getValue()>100){
						g.drawImage(image2,30, 115, 35, 30, null, null);
					}
					if (state.getKey().equals("WY") && state.getValue()<50){
						g.drawImage(image2, 130, 150, 15, 25, null, null);
					}
					else if (state.getKey().equals("WY") && state.getValue()>100){
						g.drawImage(image2, 130, 150, 35, 30, null, null);
					}
					if (state.getKey().equals("SD") && state.getValue()<50){
						g.drawImage(image2, 190, 150, 15, 25, null, null);
					}
					else if (state.getKey().equals("SD") && state.getValue()>100){
						g.drawImage(image2,190, 150, 35, 30, null, null);
					}
					if (state.getKey().equals("NE") && state.getValue()<50){
						g.drawImage(image2, 190, 208, 15, 25, null, null);
					}
					else if (state.getKey().equals("NE") && state.getValue()>100){
						g.drawImage(image2,190, 208, 35, 30, null, null);
					}
					if (state.getKey().equals("IA") && state.getValue()<50){
						g.drawImage(image2, 245, 200, 15, 25, null, null);
					}
					else if (state.getKey().equals("IA") && state.getValue()>100){
						g.drawImage(image2,245, 200, 35, 30, null, null);
					}
					if (state.getKey().equals("IL") && state.getValue()<50){
						g.drawImage(image2, 275, 220, 15, 25, null, null);
					}
					else if (state.getKey().equals("IL") && state.getValue()>100){
						g.drawImage(image2,275, 220, 35, 30, null, null);
					}
					if (state.getKey().equals("IN") && state.getValue()<50){
						g.drawImage(image2, 295, 220, 15, 25, null, null);
					}
					else if (state.getKey().equals("IN") && state.getValue()>100){
						g.drawImage(image2,295, 220, 35, 30, null, null);
					}
					if (state.getKey().equals("OH") && state.getValue()<50){
						g.drawImage(image2, 325, 220, 15, 25, null, null);
					}
					else if (state.getKey().equals("OH") && state.getValue()>100){
						g.drawImage(image2,325, 220, 35, 30, null, null);
					}
					if (state.getKey().equals("PA") && state.getValue()<50){
						g.drawImage(image2, 375, 190, 15, 25, null, null);
					}
					else if (state.getKey().equals("PA") && state.getValue()>100){
						g.drawImage(image2,375, 190, 35, 30, null, null);
					}
					if (state.getKey().equals("CA") && state.getValue()<50){
						g.drawImage(image2, 20, 250, 15, 25, null, null);
					}
					else if (state.getKey().equals("CA") && state.getValue()>100){
						g.drawImage(image2,20, 250, 35, 30, null, null);
					}
					if (state.getKey().equals("NV") && state.getValue()<50){
						g.drawImage(image2, 54, 225, 15, 25, null, null);
					}
					else if (state.getKey().equals("NV") && state.getValue()>100){
						g.drawImage(image2,54, 225, 35, 30, null, null);
					}
					if (state.getKey().equals("UT") && state.getValue()<50){
						g.drawImage(image2, 94, 225, 35, 40, null, null);
					}
					else if (state.getKey().equals("UT") && state.getValue()>100){
						g.drawImage(image2,94, 225, 35, 30, null, null);
					}
					if (state.getKey().equals("CO") && state.getValue()<50){
						g.drawImage(image2, 140, 245, 15, 25, null, null);
					}
					else if (state.getKey().equals("CO") && state.getValue()>100){
						g.drawImage(image2,140, 245, 35, 30, null, null);
					}
					if (state.getKey().equals("KS") && state.getValue()<50){
						g.drawImage(image2, 200, 270, 15, 25, null, null);
					}
					else if (state.getKey().equals("KS") && state.getValue()>100){
						g.drawImage(image2,200, 270, 35, 30, null, null);
					}
					if (state.getKey().equals("MO") && state.getValue()<50){
						g.drawImage(image2,  250, 270, 15, 25, null, null);
					}
					else if (state.getKey().equals("MO") && state.getValue()>100){
						g.drawImage(image2, 250, 270, 35, 30, null, null);
					}
					if (state.getKey().equals("KY") && state.getValue()<50){
						g.drawImage(image2, 320, 285, 25, 40, null, null);
					}
					else if (state.getKey().equals("KY") && state.getValue()>100){
						g.drawImage(image2,320, 285, 35, 30, null, null);
					}
					if (state.getKey().equals("WV") && state.getValue()<50){
						g.drawImage(image2, 351, 245, 15, 25, null, null);
					}
					else if (state.getKey().equals("WV") && state.getValue()>100){
						g.drawImage(image2,351, 245, 35, 30, null, null);
					}
					if (state.getKey().equals("VA") && state.getValue()<50){
						g.drawImage(image2,  370, 265, 15, 25, null, null);
					}
					else if (state.getKey().equals("VA") && state.getValue()>100){
						g.drawImage(image2, 370, 265, 35, 30, null, null);
					}
					if (state.getKey().equals("NC") && state.getValue()<50){
						g.drawImage(image2, 360, 305, 15, 25, null, null);
					}
					else if (state.getKey().equals("NC") && state.getValue()>100){
						g.drawImage(image2,360, 305, 35, 30, null, null);
					}
					if (state.getKey().equals("TN") && state.getValue()<50){
						g.drawImage(image2, 300, 320, 15, 25, null, null);
					}
					else if (state.getKey().equals("TN") && state.getValue()>100){
						g.drawImage(image2,300, 320, 35, 30, null, null);
					}
					if (state.getKey().equals("AR") && state.getValue()<50){
						g.drawImage(image2, 255, 350, 15, 25, null, null);
					}
					else if (state.getKey().equals("AR") && state.getValue()>100){
						g.drawImage(image2,255, 350, 35, 25, null, null);
					}
					if (state.getKey().equals("OK") && state.getValue()<50){
						g.drawImage(image2, 215, 348, 15, 25, null, null);
					}
					else if (state.getKey().equals("OK") && state.getValue()>100){
						g.drawImage(image2,215, 348, 35, 30, null, null);
					}
					if (state.getKey().equals("TX") && state.getValue()<50){
						g.drawImage(image2, 195, 425, 15, 25, null, null);
					}
					else if (state.getKey().equals("TX") && state.getValue()>100){
						g.drawImage(image2,195, 425, 35, 30, null, null);
					}
					if (state.getKey().equals("NM") && state.getValue()<50){
						g.drawImage(image2, 135, 360, 15, 25, null, null);
					}
					else if (state.getKey().equals("NM") && state.getValue()>100){
						g.drawImage(image2,135, 360, 35, 30, null, null);
					}
					if (state.getKey().equals("AZ") && state.getValue()<50){
						g.drawImage(image2, 80, 345, 15, 25, null, null);
					}
					else if (state.getKey().equals("AZ") && state.getValue()>100){
						g.drawImage(image2,80, 345, 35, 30, null, null);
					}
					if (state.getKey().equals("CA") && state.getValue()<50){
						g.drawImage(image2, 20, 255, 15, 25, null, null);
					}
					else if (state.getKey().equals("CA") && state.getValue()>100){
						g.drawImage(image2,20, 255, 35, 30, null, null);
					}
					if (state.getKey().equals("AK") && state.getValue()<50){
						g.drawImage(image2, 40, 470, 15, 25, null, null);
					}
					else if (state.getKey().equals("AK") && state.getValue()>100){
						g.drawImage(image2,40, 470, 35, 30, null, null);
					}
					if (state.getKey().equals("FL") && state.getValue()<50){
						g.drawImage(image2, 340, 465, 15, 25, null, null);
					}
					else if (state.getKey().equals("FL") && state.getValue()>100){
						g.drawImage(image2,340, 465, 35, 30, null, null);
					}
					if (state.getKey().equals("GA") && state.getValue()<50){
						g.drawImage(image2, 340, 395, 15, 25, null, null);
					}
					else if (state.getKey().equals("GA") && state.getValue()>100){
						g.drawImage(image2,340, 395, 35, 30, null, null);
					}
					if (state.getKey().equals("AL") && state.getValue()<50){
						g.drawImage(image2, 310, 395, 15, 30, null, null);
					}
					else if (state.getKey().equals("AL") && state.getValue()>100){
						g.drawImage(image2,310, 395, 35, 30, null, null);
					}
					if (state.getKey().equals("MS") && state.getValue()<50){
						g.drawImage(image2, 280, 395, 15, 25, null, null);
					}
					else if (state.getKey().equals("MS") && state.getValue()>100){
						g.drawImage(image2,280, 395, 35, 25, null, null);
					}
					if (state.getKey().equals("LA") && state.getValue()<50){
						g.drawImage(image2, 260, 435, 15, 25, null, null);
					}
					else if (state.getKey().equals("LA") && state.getValue()>100){
						g.drawImage(image2,260, 435, 35, 30, null, null);
					}
					if (state.getKey().equals("SC") && state.getValue()<50){
						g.drawImage(image2, 360, 355, 15, 25, null, null);
					}
					else if (state.getKey().equals("SC") && state.getValue()>100){
						g.drawImage(image2, 360, 355, 35, 30, null, null);
					}
					if (state.getKey().equals("HI") && state.getValue()<50){
						g.drawImage(image2, 130, 525, 15, 25, null, null);
					}
					else if (state.getKey().equals("HI") && state.getValue()>100){
						g.drawImage(image2,130, 525, 35, 30, null, null);
					}

				}
				//g.fillOval(getHeight(), getWidth(), 20, 20);
				repaint();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} //getScaledImage();

		}
		


		private BufferedImage getScaledImage(){
			BufferedImage image = new BufferedImage(getWidth(),getHeight(), BufferedImage.TYPE_INT_RGB);
			Graphics2D g2d = (Graphics2D) image.createGraphics();
			g2d.addRenderingHints(new RenderingHints(RenderingHints.KEY_RENDERING,RenderingHints.VALUE_RENDER_QUALITY));
			g2d.drawImage(mainImage.getImage(), 0, 0,getWidth(),getHeight(), null);

			return image;
		}
		public class Listener implements MouseListener{


			@Override
			public void mouseClicked(java.awt.event.MouseEvent e) {
				Rectangle2D.Double bounds = new Rectangle2D.Double(30, 30, 30, 30);
				if (bounds.contains(e.getPoint())){
					JFrame frame1= new JFrame();
					frame1.setTitle("map");
					frame1.setSize(400,300);
					frame1.setLayout(new BorderLayout());
					JComboBox<String> combo = new JComboBox<>();
					frame1.add(combo,BorderLayout.NORTH);
					frame1.setVisible(true);
					frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					frame1.pack();
				}

			}

			@Override
			public void mousePressed(java.awt.event.MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseReleased(java.awt.event.MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				// TODO Auto-generated method stub

			}

		}
	

	public static void main(String[] args){

		// Make the model
		Model model = new Model();
		model.add();
		//System.out.println("1");
		model.getStateName();
		//System.out.println("2");
		model.markState();
		//System.out.println("3");

		// Make the view
		Mapp map1= new Mapp(model);
		map1.setVisible(true);



	}




}}