package surprise_view;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class WinPanel extends JPanel {


	private static final long serialVersionUID = 1L;
	private BufferedImage earth;
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		URL resource = getClass().getResource("Surprise_images/mother-earth");
		try { 
			earth = ImageIO.read(resource);
		} catch (IOException e) {
			e.printStackTrace();
		}	
		Image image = earth.getScaledInstance(600, 600, Image.SCALE_DEFAULT);
		g.drawImage(image, 0, 0, this);
	}
	
}
