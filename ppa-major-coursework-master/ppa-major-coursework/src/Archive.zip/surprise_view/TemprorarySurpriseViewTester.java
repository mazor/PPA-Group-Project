package surprise_view;

import java.awt.Dimension;

import javax.swing.JFrame;

import surprise_model.Player;
import surprise_model.Room;

public class TemprorarySurpriseViewTester {

public static void main(String[]args) {
	
	JFrame frame = new JFrame();
	
	Room room = new Room(true);
	
	Player player = new Player(room);
	WinPanel winPanel = new WinPanel();
	LoosePanel loosePanel = new LoosePanel();
	GamePanel gamePanel = new GamePanel(player);
	
	
	frame.add(gamePanel);
	frame.pack();
	frame.setSize(new Dimension(600, 600));
	frame.setVisible(true);
	
}
	
}
