package surprise_view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class StartPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private JButton startButton;
	private JLabel titleLabel;
	private JLabel introLabel;
	private JLabel alienLabel;
	private BufferedImage alienFace;
	private BufferedImage background;

	
	
	public StartPanel() {
		setLayout(new BorderLayout(4, 1));
		JPanel northPanel = new JPanel(new GridLayout(2, 1));
		northPanel.setOpaque(false);
		northPanel.setPreferredSize(new Dimension(600, 200));
		northPanel.add(titleLabel());
		northPanel.add(introLabel());		
		add(northPanel, BorderLayout.NORTH);		
		add(startButton(), BorderLayout.CENTER);
        add(alienLabel(), BorderLayout.SOUTH);
		}
		
	
	public void nameInputField() {
		introLabel.setText("Please insert you name.");
		JTextField nameInputField = new JTextField();
		add(nameInputField, BorderLayout.CENTER);
	}
	
	
	private JLabel titleLabel() {
		Font titleFont = new Font("TitleFont", Font.BOLD + Font.ITALIC, 27);	
		titleLabel = new JLabel("Spaceship Escape");
		titleLabel.setFont(titleFont);
		titleLabel.setForeground(Color.WHITE);
		titleLabel.setHorizontalAlignment(JLabel.CENTER);
		return titleLabel;
	}
	
	
	private JLabel introLabel() {
        Font introFont = new Font("IntroFont", Font.BOLD + Font.ITALIC, 18);		
		introLabel = new JLabel("Welcome to Spaceship Escape! Click the button when you are ready to begin.");
		introLabel.setFont(introFont);
		introLabel.setBackground(null);
		introLabel.setForeground(Color.WHITE);
		introLabel.setHorizontalAlignment(JLabel.CENTER);
		return introLabel;
	}
	
		
	
	private JButton startButton() {
		Font buttonFont = new Font("ButtonFont", Font.BOLD, 20);
		startButton = new JButton("START");
		startButton.setFont(buttonFont);
		startButton.setBorderPainted(false);
		startButton.setContentAreaFilled(false);
		startButton.setForeground(Color.WHITE);		
		startButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				startButton.setEnabled(false);
				startButton.setVisible(false);
				nameInputField();
			}
			
		});
		
		
		return startButton;
	}
	
	
	public JButton getStartButton() {
		return startButton;
	}
	
	
	private JLabel alienLabel() {
		try {
		      alienFace = ImageIO.read(new File("Images/fierce-alien.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		Image alienImage = alienFace.getScaledInstance(200, 200, Image.SCALE_DEFAULT);
		ImageIcon alien = new ImageIcon(alienImage);
		
		alienLabel = new JLabel(alien);
		return alienLabel;
	}
	
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		URL resource = getClass().getResource("space-is-amazing.png");
		try { 
			background = ImageIO.read(resource);
		} catch (IOException e) {
			e.printStackTrace();
		}	
		Image image = background.getScaledInstance(800, 600, Image.SCALE_DEFAULT);
		g.drawImage(image, 0, 0, this);
	}
	
}
