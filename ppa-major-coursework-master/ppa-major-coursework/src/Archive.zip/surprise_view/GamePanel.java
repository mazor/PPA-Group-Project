package surprise_view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import surprise_model.Player;

public class GamePanel extends JPanel {


	private static final long serialVersionUID = 1L;

	
	private JButton houxButton;
	private JButton notHouxButton;
	
	
	private JPanel leftDoor;
	private JPanel rightDoor;
	
	private JPanel floor;
	private JPanel wall;
	private JPanel roof;
	
	
	private JLabel description;
	
	
	private BufferedImage alienWarningSign;
	private BufferedImage doorKnobImage;
	
	private Player player;
	
	
	public GamePanel(Player player) {
	
		this.player = player;
		
		setLayout(new BorderLayout());		
		add(floor(), BorderLayout.SOUTH);
		add(wall(), BorderLayout.CENTER);
		add(roof(player.getRoomUfoObservation()), BorderLayout.NORTH);
	}
	
	
	private JPanel roof(String descriptionOfSighting) {
		roof = new JPanel(new GridLayout(1, 1));
		roof.setPreferredSize(new Dimension(600, 150));
		roof.setBackground(Color.BLUE);	
		Font descriptionFont = new Font("DescriptionFont", Font.BOLD, 16);
		description = new JLabel("Observation: " + descriptionOfSighting);
		description.setHorizontalAlignment(JLabel.HORIZONTAL);
		description.setFont(descriptionFont);
		description.setForeground(Color.WHITE);	
		roof.add(description);
		return roof;
	}
	
	
	private JPanel floor() {
		floor = new JPanel(new FlowLayout(FlowLayout.CENTER, 160, 60));
		floor.setBackground(Color.BLACK);
		floor.setPreferredSize(new Dimension(600, 150));
		floor.setAlignmentX(CENTER_ALIGNMENT);		
		houxButton = new JButton("Houx");
		notHouxButton = new JButton("Not a houx");
        floor.add(houxButton);
		floor.add(notHouxButton);      
		return floor;
	}
	
	
	private JPanel wall() {
		wall = new JPanel(new GridLayout(1, 5));
		wall.setBackground(Color.BLUE);
		
		JPanel blankSpace = new JPanel();
		JPanel blankSpace2 = new JPanel();
		JPanel blankSpace3 = new JPanel();		
		blankSpace.setOpaque(false);
		blankSpace2.setOpaque(false);
		blankSpace3.setOpaque(false);
		
		makeMeADoor(leftDoor);
		makeMeADoor(rightDoor);
		
		wall.add(blankSpace);
		wall.add(makeMeADoor(leftDoor));
		wall.add(blankSpace2);
		wall.add(makeMeADoor(rightDoor));
		wall.add(blankSpace3);
				
		return wall;
	}
	
	
	
	private JPanel makeMeADoor(JPanel iWannaBeADoor) {
		 iWannaBeADoor = new JPanel(new BorderLayout());
		 iWannaBeADoor.setBackground(Color.LIGHT_GRAY);	
			try {
			      alienWarningSign = ImageIO.read(new File("src/surprise_view/aliens-ahead.png"));
			} catch (IOException e) {
				e.printStackTrace();
			}			
			Image alienWarningImage = alienWarningSign.getScaledInstance(100, 100, Image.SCALE_DEFAULT);
			ImageIcon alienSign = new ImageIcon(alienWarningImage);
			
			JLabel warningLabel = new JLabel(alienSign);			
			iWannaBeADoor.add(warningLabel, BorderLayout.CENTER);
				
			try {
			      doorKnobImage = ImageIO.read(new File("src/surprise_view/Doorknob.png"));
			} catch (IOException e) {
				e.printStackTrace();
			}			
			Image doorKnobImageScaled = doorKnobImage.getScaledInstance(20, 20, Image.SCALE_DEFAULT);
			ImageIcon doorKnob = new ImageIcon(doorKnobImageScaled);
			
			JLabel doorKnobLabel = new JLabel(doorKnob);		
			iWannaBeADoor.add(doorKnobLabel, BorderLayout.EAST);
					
			return iWannaBeADoor;
		}
		
		
	}
